import React, { useEffect, useState, useRef } from "react";
// import Slider from "react-slick";
import { Row, Col, Container, Modal } from "react-bootstrap";
import {
  HeadingDesc,
  HeadingDescSmall,
  HeadingDescVsmall,
} from "../../uiComponents/Headings";

import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// import { URL } from "../../constants";
// import { RatingStars } from "../../uiComponents/rating";
// import { RankTag } from "../../uiComponents/tags";
import { TableComponent } from "../../uiComponents/tableComponent";
// import tagIcon from "../../assets/images/svg/platinium-rank.svg";
import upcomingImg from "../../assets/images/svg/upcomingIcon.svg";
import bulletGreen from "../../assets/images/svg/bulletgreen.svg";
// import drProfileImg from "../../assets/images/png/dr-profile.png";
import { RiArrowRightSLine, RiArrowLeftSLine } from "react-icons/ri";
import { Link, useHistory, useLocation } from "react-router-dom";
// import { FiArrowLeftCircle, FiArrowRightCircle } from "react-icons/fi";
import { getDashboardDetails } from "./redux/thunk";
import { useAppDispatch, useAppSelector } from "./../../redux/hooks";
import { selectDashboard } from "./redux/slice";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./_dashboard.scss";
import SimpleSlider from "../../uiComponents/sliders/simpleSlider/SimpleSlider";
// import { SimpleButton } from "../../uiComponents/button";
import moment from "moment";
// import { FaArrowCircleRight, FaRegTimesCircle, FaTimes, FaTimesCircle } from "react-icons/fa";
import swal from "sweetalert";
import StarRating from "../../uiComponents/rating/ratingStars/StarRating";
import loadingGif from "../../assets/images/gif/loader_gif.gif";
import SimpleInstantSlider from "../../uiComponents/sliders/simpleSlider/SimpleInstantSlider";
import StickyTab from "../../uiComponents/stickyTab/StickyTab";
import CountdowmTimer from "../../uiComponents/countdownTimer/CountdowmTimer";
import { AiTwotoneLike } from "react-icons/ai";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button, Switch, Modal as AntModal, Checkbox } from "antd";
// import Reviews from "../../uiComponents/reviews/Reviews";
// import {useEffectOnce} from "react-use";
// import { getProfile } from "../updateProfile/redux/thunk";
import { getCurrentUserData } from "../../utils/powerFuntions";
import axios from "axios";
import { FiChevronRight } from "react-icons/fi";
import classNames from "classnames";
import notificationSound from "../../assets/audio/appointment-notification.mp3";
import circleCheck from "../../assets/images/png/circle-check.png";
import { isEmpty } from "../../helpers/objectHelper";
import Loader from "../../uiComponents/loader/Loader";
import FriendlyPolite from "../../assets/images/png/friendly-polite.png";
import disableConsultation from "../../assets/images/svg/instant-disable-modal.svg";
import AgoraRTM from "agora-rtm-sdk";
import API from "../../utils/customAxios";
import { ConsoleIcon } from "evergreen-ui";
import { Accordion } from "react-bootstrap";
import getAppointmentTypeText from "../../utils/appointmentTypes";
import { getUserId } from "../../helpers/authHelper";
import Cookies from "js-cookie";
import InstantTable from "../../uiComponents/tableComponent/InstantTable";
import DashboardNew from "../dashboardNew/DashboardNew";
import patientIcon from "../../assets/images/png/patient_icon.png";
import dateIcon from "../../assets/images/png/date_icon.png";
import timeIcon from "../../assets/images/png/time_icon.png";
import appointmentTypeIcon from "../../assets/images/png/appointment-type_icon.png";
import attachmentIcon from "../../assets/images/png/attachment-icon.png";
import mailIcon from "../../assets/images/png/mail_icon.png";
import whatsappIcon from "../../assets/images/png/whatsapp_icon.png";
import { generateDobArray, generateDobYears, isAlphabetsOnly, isDigits } from "../../utils/helperFunctions";
import { EmailShareButton, WhatsappShareButton } from "react-share";

function Dashboard() {
  const dispatch = useAppDispatch();
  const selectDashboardDetails = useAppSelector(selectDashboard);

  const checkboxRef = useRef();
  const history = useHistory();

  const [summary, setSummary] = useState([]);
  const [review, setReview] = useState({});
  const [bodyData, setBodyData] = useState();
  const [badge, setBadge] = useState("");
  const [todayDate, setDate] = useState("");
  const [datefilter, setDateFilter] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [appointmentsCard, setAppointmentsCard] = useState({});
  const [instantData, setInstantData] = useState();
  const [upcomingApp, setUpcomingApp] = useState([]);
  const [showDashboard, setShowDashboard] = useState(true);
  const [showReviews, setShowReviews] = useState(false);
  const [pendingAppointments, setPendingAppointments] = useState(false);
  const [pendingLoading, setPendingLoading] = useState(false);
  const [profileVerificationDoctor, setProfileVerificationDoctor] =
    useState(null);

  const [doctorData, setDoctorData] = useState({});
  const [isOnline, setIsOnline] = useState(false);
  const [openPop, setOpenPop] = useState(false);
  const [temrsCheckbox, setTemrsCheckbox] = useState();

  const [instantDiscountData, setInstantDiscountData] = useState({});

  const [showInstantConsultations, setShowInstantConsultations] =
    useState(true);

  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [showAppointmentSuccessModal, setShowAppointmentSuccessModal] = useState(false);

  //Create Appointment State

  // const [createAppointmentData, setCreateAppointmentData] = useState({
  //   name: '',
  //   gender: 'male',
  //   phone: '',
  //   network: 'zong',
  //   day: '1',
  //   month: '1',
  //   year: '2023',
  //   weight: '30',
  //   height: '20'
  // });

  const [nameValue, setNameValue] = useState('');
  const [genderValue, setGenderValue] = useState('male');
  const [phoneValue, setPhoneValue] = useState('');
  const [networkValue, setNetworkValue] = useState('zong');
  const [dayValue, setDayValue] = useState('1');
  const [monthValue, setMonthValue] = useState('1');
  const [yearValue, setYearValue] = useState('2023');
  const [weightValue, setWeightValue] = useState('30');
  const [heightValue, setHeightValue] = useState('20');

  const [nameError, setNameError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [genderError, setGenderError] = useState('');
  const [heightError, setHeightError] = useState('');
  const [weightError, setWeightError] = useState('');
  const [dateOfBirthError, setDateOfBirthError] = useState('');
  const [generalError, setGeneralError] = useState('');


  // state for appointment success

  const [externalLink, setExternalLink] = useState('');

  const [appointmentSuccessData, setAppointmentSuccessData] = useState({
    name: '',
    type: '',
    date: '',
    time: ''
  });

  const handleChangeTerms = (e) => {
    if (e.target.checked === true) {
      setTemrsCheckbox(true);
    } else {
      setTemrsCheckbox(false);
    }
  };

  useEffect(() => {
    // setTimeout(() => {
    //   if (!localStorage.getItem('showPopup')) {
    //     setOpenPop(true)
    //   }
    // }, 3000);
    var is_modal_show = sessionStorage.getItem("alreadyShow");
    if (is_modal_show !== "alreadyshown") {
      setTimeout(() => {
        setOpenPop(true);
      }, 3000);
      sessionStorage.setItem("alreadyShow", "alreadyshown");
    } else {
      setOpenPop(false);
    }
  }, []);

  // console.log(bodyData, "bodyData");
  const [mobile, setMobile] = useState(false);
  const location = useLocation();
  // console.log(location);
  const [loading, setLoading] = useState(false);

  const [show, setShow] = useState(false);
  const [cancel, setCancel] = useState(false);
  const [arrived, setArrived] = useState(false);
  const [doctorOn, setDoctorOn] = useState(false);

  const [showWarningModal, setShowWarningModal] = useState(false);

  const [rtmToken, setRtmToken] = useState(false);
  const [showStartLoader, setShowStartLoader] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleShow2 = () => setDoctorOn(true);
  const handlehide2 = () => setDoctorOn(false);

  const handleCloseCreateAppointment = () => {
    setShowAppointmentModal(false);
    setPhoneValue('')
    setNameError('')
    setGenderError('')
    setPhoneError('')
  }
  const handleCloseAppointmentSuccess = () => setShowAppointmentSuccessModal(false);

  const forReviews = () => {
    setShowDashboard(false);
    setShowReviews(true);
  };
  const handleOkay = () => {
    setShow(false);
    setCancel(true);
  };
  const handleOkayClose = () => setCancel(false);
  const handleArrived = () => setArrived(false);

  useEffect(() => {
    (async () => {
      const res = await getCurrentUserData();
      if (res) {
        setDoctorData(res);
      }

      if (res?.is_instant_consultation === true) {
        setIsOnline(true);
      }
    })();
  }, []);

  // useEffect(() => {
  //   setTimeout(() => {

  //   }, 3000);

  // }, [doctorData?.is_instant_consultation])

  // useEffect(() => {
  //   (async() => {
  //     const response = await API.get(`/generate-agora-rtm-token`);
  //     if(response?.data?.code === 200) {
  //       setRtmToken(response?.data?.data?.token);
  //     }
  //   })()

  // }, [])

  useEffect(() => {
    if (typeof window !== "undefined") {
      if (window.innerWidth < 600) {
        setMobile(true);
      }
    }
    dispatch(getDashboardDetails());
  }, []);

  function cancelToggler() {
    swal({
      title: "Are you sure?",
      text: "Clicking OK will cancel the appointment",
      icon: "warning",
      buttons: true,
    }).then((willCancel) => {
      if (willCancel) {
        swal("Your appointment has been cancelled", {
          icon: "success",
        });
      } else {
        return null;
      }
    });
  }

  const hideModalAndInstantOpen = () => {
    setIsOnline(true);
    setDoctorOn(false);
  };

  async function onCheckboxChange(e) {
    // console.log(e.target.checked, 'isOnliness');
    // setIsOnline(e.target.checked);

    if (!isOnline) {
      handleShow2();
    }

    const userId = getUserId();

    const options = {
      headers: { Authorization: Cookies.get("token") },
    };

    if (e === true) {
      const data = {
        is_instant_consultation: 1,
      };

      const response = await axios.post(
        `${process.env.REACT_APP_BASE_URL}/doctor/instant-online-offline`,
        data,
        options
      );

      if (response?.data?.code === 200) {
        if (doctorOn) {
          hideModalAndInstantOpen();
        }
      } else {
        setIsOnline(false);
      }
    } else {
      const appointments = pendingAppointments;

      let instantAppointments = appointments.filter(
        (item) =>
          item?.type === "instant-consultation" && item?.progress === "pending"
      );

      if (instantAppointments?.length > 0) {
        // swal("Appointments Pending!", "Please complete your pending appointments", "error");
        setShowWarningModal(true);
        setIsOnline(isOnline);
      } else if (!instantAppointments?.length > 0) {
        // setShowWarningModal(true);
        toast.error("DoctorNow Disabled");
      }

      const data = {
        is_instant_consultation: 0,
      };

      const response = await axios.post(
        `${process.env.REACT_APP_BASE_URL}/doctor/instant-online-offline`,
        data,
        options
      );

      if (response?.data?.code === 200) {
        setIsOnline(false);
      } else {
        setIsOnline(true);
      }
    }
  }

  async function emitAppointmentStart(e, record) {
    if (record.canStart) {
      if (showStartLoader) {
        return;
      }

      setShowStartLoader(true);
      e.preventDefault();
      // console.log(record, "record");

      let options = {
        uid: "",
        token: "",
      };

      const appID = process.env.REACT_APP_AGORA_TEST_APP_ID;
      const appointmentId = record?.id;

      let token;
      let channelName = `${appointmentId}`;
      const response = await API.get(`/generate-agora-rtm-token`);
      if (response?.data?.code === 200) {
        token = response?.data?.data?.token;

        // console.log({token});

        if (token) options.token = token;

        if (appID && channelName) {
          const client = AgoraRTM.createInstance(appID);

          // console.log(token, "token");
          // console.log(doctorData?.id, "docData")
          await client.login({ token, uid: `${doctorData?.id}` });
          // await client.login();

          let channel = client.createChannel(channelName);

          await channel.join();

          await channel
            .sendMessage({ text: "appointment-started" })
            .then(() => {
              setShowStartLoader(false);
              history.push({
                pathname: `/appointment/${record?.id}`,
                state: {
                  id: record?.id,
                  type: record?.type,
                  user_id: record?.user_id,
                  visit_count: record?.visit_count,
                },
              });
            });
        }
      }
    }
  }

  let header = [
    { title: "Patients", dataIndex: "patients" },
    {
      title: "Date",
      dataIndex: "date",
      sorter: {
        compare: (a, b) => a.date.localeCompare(b.date),
        multiple: 3,
      },
    },
    {
      title: "Consultation Time",
      dataIndex: "time",
      sorter: {
        compare: (a, b) => a.time.localeCompare(b.time),
        multiple: 2,
      },
    },
    {
      title: "Type",
      dataIndex: "type",
      sorter: {
        compare: (a, b) => a.type.localeCompare(b.type),
        multiple: 1,
      },
      render(text, record) {
        // console.log(text);
        if (text != null) {
          return {
            props: {
              style: {
                color: text.toLowerCase().startsWith("in-")
                  ? "#ff8900"
                  : text.toLowerCase().startsWith("i")
                    ? "#EF6286"
                    : "#29BCC1",
              },
            },

            children: <div className="capitalize">{text}</div>,
          };
        }
      },
    },
    { title: "Visit Count", dataIndex: "visit_count" },
    {
      title: "Action",
      dataIndex: "consult",
      align: "center",
      render(text, record) {
        // console.log(text, record, 'textrecord');

        // console.log(record?.progress);
        return {
          children: (
            <div>
              {record?.progress === "completed" ? (
                <Link
                  className="consult_later"
                  to={{
                    pathname: `/past-consultation/${record?.key}`,
                    state: {
                      id: record.key,
                      type: record?.type,
                      user_id: record?.user_id,
                      visit_count: record?.visit_count,
                    },
                  }}
                >
                  <div className="inline_data btn btn-transparent">
                    <p className="completed">View Details</p>
                  </div>
                </Link>
              ) : record?.progress !== "completed" ? (
                <div className="inline-data text-center align-items-end">
                  <div>
                    <div className="d-flex mb-2">
                      <p className="fs-13">Status</p>
                      <div className="status-tag-action text-uppercase arrived-tag _pending-tag ms-1">
                        Arrived
                      </div>
                    </div>
                    <Link
                      className="consult_now"
                      to={{
                        pathname: `/appointment/${record?.key}`,
                        state: {
                          id: record.key,
                          type: record?.type,
                          user_id: record?.user_id,
                          visit_count: record?.visit_count,
                        },
                      }}
                    >
                      <div className="inline_data btn btn-theme ">
                        <>
                          <p className="text-white">START</p>
                        </>
                      </div>
                    </Link>
                  </div>
                  {record?.type !== "instant-consultation" && (
                    <div className="cancel_now ms-4">
                      {/* <div className="inline_data btn btn-transparent" style={{ cursor: 'pointer' }} onClick={cancelToggler}> */}
                      <div
                        className="inline_data btn btn-transparent"
                        style={{ cursor: "pointer" }}
                        onClick={handleShow}
                      >
                        <p>CANCEL</p>
                      </div>

                      {/* <RiArrowRightSLine className="arrow_grey" /> */}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  className="consult_later"
                  to={{
                    pathname: `/appointment/${record?.key}`,
                    state: {
                      id: record.key,
                      type: record?.type,
                      user_id: record?.user_id,
                      visit_count: record?.visit_count,
                    },
                  }}
                >
                  <div className="inline_data">
                    <p>Appointment incomplete</p>
                    <RiArrowRightSLine className="arrow_grey" />
                  </div>
                </Link>
              )}
            </div>
          ),
        };
      },
    },
  ];

  let instantHeader = [
    { title: "Patient Name", dataIndex: "patients" },
    {
      title: "Date  ",
      dataIndex: "date",
      // sorter: {
      //   compare: (a, b) => a.date.localeCompare(b.date),
      //   multiple: 3,
      // },
    },
    {
      title: "Consultation Time",
      dataIndex: "time",
      // sorter: {
      //   compare: (a, b) => a.time.localeCompare(b.time),
      //   multiple: 2,
      // },
    },
    {
      title: "Type",
      dataIndex: "type",
      // sorter: {
      //   compare: (a, b) => a.type.localeCompare(b.type),
      //   multiple: 1,
      // },
      render(text, record) {
        // console.log(text);
        if (text != null) {
          return {
            props: {
              style: {
                color: text.toLowerCase().startsWith("in-")
                  ? "#ff8900"
                  : text.toLowerCase().startsWith("i")
                    ? "#EF6286"
                    : "#29BCC1",
              },
            },

            children: <div className="capitalize">{text}</div>,
          };
        }
      },
    },
    { title: "Visit Count", dataIndex: "visit_count" },
    {
      title: "Action",
      dataIndex: "consult",
      align: "center",
      render(text, record) {
        // console.log(record?.progress);
        // console.log({record})
        return {
          children: (
            <div>
              {record?.type === "instant-consultation" && (
                <div>
                  {/* <div className="d-flex mb-2">
                      <p className='fs-13'>Status</p>
                      <div className="status-tag-action text-uppercase arrived-tag _pending-tag ms-1">
                          Arrived
                      </div>
                    </div> */}
                  <div className="box_table_call">
                    {/* <p className="st01">Status <span className="status bg-green">ARRIVED</span></p> */}
                    <div className="d-flex  ">
                      <Link
                        onClick={(e) =>
                          emitAppointmentStart(e, {
                            id: record?.key,
                            type: record?.type,
                            user_id: record?.user_id,
                            visit_count: record?.visit_count,
                            canStart: record?.canStart,
                          })
                        }
                        className={classNames(
                          "w-100   consult_now consult_now_instant justify-content-start",
                          {
                            "disable-now-btn":
                              record?.canStart === false ||
                              showStartLoader === true,
                          }
                        )}
                        to={{
                          pathname:
                            record?.canStart === true
                              ? `/appointment/${record?.key}`
                              : "/#",
                          state: {
                            id: record.key,
                            type: record?.type,
                            user_id: record?.user_id,
                            visit_count: record?.visit_count,
                          },
                        }}
                      >
                        <div
                          className="w-100 inline_data btn btn-theme justify-content-center"
                          style={{ minWidth: "100%", maxWidth: "100%" }}
                        >
                          <p className="text-white">START</p>
                        </div>
                      </Link>
                      {/* <Link className="btn btn-cancil01">CANCEL</Link> */}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ),
        };
      },
    },
  ];

  // console.log({ instantData });

  const onChange = (pagination, filters, sorter, extra) => {
    // console.log('params', pagination, filters, sorter, extra);
  };

  useEffect(() => {
    if (selectDashboardDetails?.data) {
      // console.log("exec");
      setReviews(selectDashboardDetails?.data?.reviews?.reviews);
      let appointments_card = selectDashboardDetails?.data?.appointments_count;
      // console.log(appointments_card, 'appointments_card');

      setAppointmentsCard(appointments_card);

      let d = new Date();
      d = d.toLocaleString("default", {
        day: "numeric",
        month: "short",
        year: "numeric",
      });
      const quickSummary = [
        {
          title: "Appointments",
          date: d,
          number: appointments_card.appointment_today_total,
        },
        {
          title: "Clinic visits for today",
          date: "Till Date",
          number: appointments_card.physical_appointment,
        },
        {
          title: "Video consultations for today",
          date: d,
          number: appointments_card.virtual_appointment,
        },
        {
          title: "Total Earnings",
          date: d,
          number: `Rs.${appointments_card.total_earning}`,
        },
        {
          title: "Total Receivables",
          subtitle: "You will receive your earnings every 15 days",
          date: d,
          number: `Rs.${appointments_card.total_receivables}`,
        },
        {
          title: (
            <div>
              DoctorNow <span>(Instant video calls)</span>
            </div>
          ),
          date: d,
          number: appointments_card.cancelled_by_doctor,
        },
      ];
      setSummary(quickSummary);

      let doctor_review = {
        average: selectDashboardDetails?.data?.review_avg,
        total: selectDashboardDetails?.data?.review_count,
      };
      setReview(doctor_review);
      let doc_badge = doctorData?.badge;

      let app_table = [];

      if (pendingAppointments.length > 0) {
        let appointments_table = pendingAppointments;
        // console.log({appointments_table})

        let upcoming = appointments_table?.filter(
          (app) => app?.progress === "pending"
        );
        let upcom_app = [];

        console.log(upcoming?.[0]?.appointment_time, 'sascac')
        if (upcoming?.length > 0) {
          const start = upcoming?.[0]?.appointment_time?.split(":");
          var timee = new Date(0, 0, 0, start?.[0], start?.[1], 0);
          const ap_date = upcoming?.[0]?.date?.split("-");
          var date = new Date(ap_date?.[0], ap_date?.[1] - 1, ap_date?.[2]);
          let appointment_date = date?.toLocaleString("en-US", {
            month: "short",
            day: "numeric",
          });
          let appointment_time = timee?.toLocaleString("en-US", {
            hour: "numeric",
            hour12: true,
            minute: "numeric",
          });

          upcom_app.push(upcoming?.[0]);
          upcom_app.push(appointment_time);
          upcom_app.push(appointment_date);
          setUpcomingApp(upcom_app);
        }

        appointments_table?.map((data, index) => {
          // console.log(data, 'zain')
          try {
            const start = data?.appointment_time?.split(":");
            var timee = new Date(0, 0, 0, start?.[0], start?.[1], 0);
            const ap_date = data?.appointment_date?.split("-");
            var date = new Date(ap_date?.[0], ap_date?.[1] - 1, ap_date?.[2]);
            let appointment_date = date?.toLocaleString("en-US", {
              month: "short",
              day: "numeric",
            });
            // let appointment_time =  timee?.toLocaleString("en-US", {
            //   hour: "numeric",
            //   hour12: true,
            //   minute: "numeric",
            // });
            // ? moment(data?.schedule_date).format("LT") : ''
            let progress = data?.progress;
            let myobj = {
              key: data?.id,
              user_id: data?.user_id,
              patients: data?.patient_name
                ? data?.patient_name
                : data?.user?.name,
              date: moment(data?.created_at)?.format("DD/MM/YY"),
              // time: moment(appointment_date)?.format("LT"),
              time: data?.schedule_date ? data?.schedule_date.slice(0, 8) : '',
              type: data?.type,
              fees: data?.consultation_fee,
              visit_count: data?.user?.appointment_count?.toString(),
              consult: data?.seconds_left <= 0,
              progress,
            };

            setDate(moment(data?.created_at).format("DD/MM/YY"));
            app_table.push(myobj);
          } catch (error) {
            let appointment_date = "";
            let appointment_time = "";
            let myobj = {
              key: data?.id,
              patients: data?.user?.name,
              date: moment(data?.created_at).format("DD/MM/YYYY"),
              time: appointment_time,
              type: data?.type,
              fees: data?.consultation_fee,
              visit_count: data?.user?.appointment_count?.toString(),
              consult: data?.seconds_left <= 0,
            };
            setDate(appointment_date);
            app_table.push(myobj);
          }
        });

        console.log(app_table, 'app_table');
        let double_table;
        double_table = app_table.filter(
          (data) => data?.type !== "instant-consultation"
        );

        const body_data = double_table;
        setBodyData(body_data);
        setBadge(doc_badge);

        let single_table;
        single_table = app_table.filter(
          (data) =>
            data?.type === "instant-consultation" &&
            data?.progress === "pending"
        );
        // console.log({single_table})

        single_table?.sort((a, b) => a?.key - b?.key);
        single_table?.map((s, index) => {
          if (index === 0 || doctorData?.is_created_appointment_allowed == 1) {
            s.canStart = true;
          } else {
            s.canStart = false;
          }
        });
        // console.log(single_table, 'single_table');
        setInstantData(single_table);
      }
    }
  }, [selectDashboardDetails, pendingAppointments?.length]);

  // console.log({instantData});

  // console.log({instantData})

  useEffect(() => {
    addDays();
  }, []);

  useEffect(() => {
    setPendingLoading(true);
    API.get(`/doctor/pending-appointment`)
      .then((res) => {
        if (res?.data?.code === 200) {
          setPendingLoading(false);
          setPendingAppointments(res?.data?.data);
        } else {
          setPendingLoading(false);
        }
      })
      .catch((err) => {
        setPendingLoading(false);
      });
  }, []);

  useEffect(() => {
    let quickSummaryContainer = document.querySelector(
      ".quickSummaryContainer"
    );
    quickSummaryContainer?.click();
    let audio = new Audio(notificationSound);

    const interval = setInterval(() => {
      API.get(`/doctor/pending-appointment`)
        .then((res) => {
          if (res?.data?.code === 200) {
            if (res?.data?.data?.length > 0) {
              audio.play();
            }
            setPendingAppointments(res?.data?.data);
          }
        })
        .catch((err) => { });

      // if (instantData?.length > 0) {
      //   audio.play();
      // }
    }, 15000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  const padStart = (val) => {
    return val < 10 ? "0" + val : val;
  };
  const addDays = () => {
    const date = new Date();
    let datesCollection = [];

    for (var i = 0; i < 60; i++) {
      const newDate = new Date(date.getTime() + i * 1000 * 60 * 60 * 24);
      datesCollection.push(
        `${newDate.getFullYear()}/${padStart(
          newDate.getMonth() + 1
        )}/${padStart(newDate.getDate())}/`
      );
    }
    setDateFilter(datesCollection);
  };

  const formatedDate = datefilter?.map((item, index) => {
    if (index === 0) {
      return (
        moment(new Date(item)).format("ddd") +
        ", " +
        moment(new Date(item)).format("MMM D")
      );
    } else {
      return (
        moment(new Date(item)).format("ddd") +
        ", " +
        moment(new Date(item)).format("MMM D")
      );
    }
  });
  // // console.log(formatedDate)
  const buttons = datefilter?.map((index) => {
    // const { btnText, link } = item;
    // return <SimpleButton text={item} key={index} />;

    return (
      <TableComponent
        key={index}
        header={header}
        data={bodyData}
        pagination={false}
        onChange={onChange}
      />
    );
  });

  // console.log(review.average, "review");

  function updateTableData() {
    // let appointments_table = selectDashboardDetails?.data?.appointment_listing;
    let appointments_table = pendingAppointments;
    let app_table = [];
    appointments_table?.map((data, index) => {
      // console.log("app-type", data?.type)

      try {
        const start = data?.appointment_time?.split(":");
        var timee = new Date(0, 0, 0, start?.[0], start?.[1], 0);
        const ap_date = data?.appointment_date?.split("-");
        var date = new Date(ap_date?.[0], ap_date?.[1] - 1, ap_date?.[2]);
        let appointment_date = date?.toLocaleString("en-US", {
          month: "short",
          day: "numeric",
        });
        let appointment_time = timee?.toLocaleString("en-US", {
          hour: "numeric",
          hour12: true,
          minute: "numeric",
        });
        let myobj = {
          key: data?.id,
          user_id: data?.user_id,
          patients: data?.patient_name,
          date: appointment_date,
          time: appointment_time,
          type: data?.type,
          fees: data?.consultation_fee,
          visit_count: data?.user?.appointment_count?.toString(),
        };
        setDate(appointment_date);
        app_table.push(myobj);
      } catch (error) {
        let appointment_date = "";
        let appointment_time = "";
        let myobj = {
          key: data?.id,
          patients: data?.user?.name,
          date: appointment_date,
          time: appointment_time,
          type: data?.type,
          fees: data?.consultation_fee,
          visit_count: data?.user?.appointment_count?.toString(),
        };
        setDate(appointment_date);
        app_table.push(myobj);
      }
    });

    return app_table;
  }

  function onTypeFilterClick(e) {
    // console.log(e?.key);

    let datee = [];
    formatedDate?.map((d) => datee.push(d?.split(", ")[1]));

    // console.log(datee, 'datee');

    if (e?.key == "3") {
      // window.location.reload();

      let app_table = updateTableData();

      setBodyData(app_table);
    } else if (Array.isArray(bodyData)) {
      let app_table = updateTableData();
      setBodyData(app_table?.filter((d) => d?.type?.toLowerCase() == e?.key));

      // // setBodyData(app_table);

      // setBodyData(bodyData?.filter((d) => d?.type?.toLowerCase() == e?.key));
    }
  }

  async function refreshTableData(e) {
    e.target.classList.add("pi-spin");
    await dispatch(getDashboardDetails()).then((data) => {
      // console.log(data);
      if (data) {
        e.target.classList.remove("pi-spin");
      }
    });
  }

  const menuList = [
    {
      link: "#overview",
      name: "Overview",
    },
    {
      link: "#badge",
      name: "Badge",
    },
    {
      link: "#reviews",
      name: "Your Reviews",
    },
  ];

  function submitCancelFeedback() {
    setCancel(false);
  }

  function navigateToReviews() {
    history.push("/reviews");
  }

  useEffect(() => {
    (async () => {
      const res = await API.get(`/doctor/earning-break-down`);
      if (res) {
        setInstantDiscountData(res?.data?.data);
      }
    })();
  }, []);

  // console.log({ pendingAppointments });

  useEffect(() => {
    (async () => {
      try {
        const response = await API.get(`doctor/progress`);

        if (response?.data?.code === 200) {
          setProfileVerificationDoctor(
            response?.data?.data?.profile_verification
          );
        }
      } catch (error) { }
    })();
  }, [profileVerificationDoctor]);

  async function copyTextToClipboard(e, text) {
    if ('clipboard' in navigator) {
      return await navigator.clipboard.writeText(text);
    } else {
      return document.execCommand('copy', true, text);
    }
  }

  async function createAppointmentHandler(e) {
    e.preventDefault();

    setNameError('')
    setPhoneError('');
    setGenderError('');
    setDateOfBirthError('');
    setHeightError('');
    setWeightError('');
    setGeneralError('');

    // const {name, phone, day, month, year, gender, network, height, weight} = createAppointmentData;

    let name = nameValue;
    let phone = phoneValue;
    let day = dayValue;
    let month = monthValue;
    let year = yearValue;
    let gender = genderValue;
    let network = networkValue;
    let height = heightValue;
    let weight = weightValue;

    let currDate = moment().format().substring(0, 10);

    let dateSplit = currDate.split("-");

    if (!name) {
      setNameError('Name is Required')
    }

    else if (!isAlphabetsOnly(name)) {
      setNameError("Name is invalid");
    }

    else if (phone.trim().length <= 0) {
      setPhoneError('Phone is required');
    }

    else if (!isDigits(phone) || phone.trim().length !== 11) {
      setPhoneError("Phone is invalid");
    }

    else if (!day || !month || !year) {
      setDateOfBirthError("Date of Birth is invalid");
    }

    else if (!gender) {
      setGenderError("Gender is required");
    }

    else if (!height) {
      setHeightError("Height is required");
    }

    else if (!weight) {
      setWeightError("Weight is requied");
    }

    else if (year == dateSplit[0] && month == dateSplit[1] && day == dateSplit(2)) {
      setDateOfBirthError("Date is invalid");
    }

    else {
      let payload = {
        name,
        phone,
        network,
        date_of_birth: `${day}-${month}-${year}`,
        gender,
        height,
        weight
      };

      try {
        const response = await API.post("/doctor/create-instant-appointment", payload);

        if (response?.data?.code === 200) {
          const siteUrl = process.env.REACT_APP_FOOTER_BASE_URL;
          const appointmentId = response?.data?.data?.appoitment?.id;
          const token = response?.data?.data?.hash;

          setExternalLink(`${siteUrl}/dynamic-appointment/${appointmentId}?token=${token}`);

          let type;

          if (response?.data?.data?.appoitment?.type === 'instant-consultation') {
            type = "Instant Consultation"
          }

          setAppointmentSuccessData({
            name: response?.data?.data?.appoitment?.patient_name,
            type,
            date: response?.data?.data?.appoitment?.date,
            time: response?.data?.data?.appoitment?.time
          })

          setShowAppointmentModal(false);
          setShowAppointmentSuccessModal(true);
        }

        else {
          toast.error(response?.data?.message);
        }

      } catch (error) {
        console.error(error);
        setGeneralError(error?.response?.data?.message || error?.message);
        toast.error(error?.response?.data?.message || error?.message);
      }
    }


  }


  function nameHandler(e) {
    setNameValue(e.target.value);
  }

  function phoneHandler(e) {
    const inputValue = e.target.value.slice(0, 11); // Limit input to 11 characters
    setPhoneValue(inputValue);
    if (/^\d{0,11}$/.test(inputValue)) {
      console.log(phoneValue, "setPhoneValue")
      setPhoneError('');
    } else {
      setPhoneError('Phone must be exactly 11 digits');
    }
  }


  return (
    <div className="bg_color_db">
      {isEmpty(doctorData) || pendingLoading || showStartLoader ? (
        <Loader />
      ) : (
        <section className="dashboard bgLinghtGray dash_wrapper cover_space">
          <>
            {summary?.length === 0 ? (
              <div className="loaderWrapper">
                <img src={loadingGif} alt="" />
              </div>
            ) : (
              <>
                {mobile && <StickyTab menuList={menuList} type="a" />}
                {showDashboard && (
                  <>
                    <Container fluid>
                      {!mobile && (
                        <Row>
                          <Col lg={12}>
                            {/* <HeadingWithSpaceLarge text="DASHBOARD" /> */}
                          </Col>
                        </Row>
                      )}
                      <Row>
                        {doctorData && (
                          <Col lg={12}>
                            <div className="mt-0 card bg-white p-3 d-md-flex flex-row align-items-end justify-content-between d-block hk_firstfold">
                              <div className="d-flex align-items-center">
                                <div className="d-flex flex-md-row flex-column">
                                  <div className="nameDoctor order-2 order-md-1">
                                    <h4 className="color-313131">
                                      Dashboard
                                    </h4>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Col>
                        )}
                      </Row>
                      <Row>
                        <Col md={12}>
                          <div className="patient_wrapper_main mt-5">
                            <div className="nameDoctor order-2 order-md-1">
                              <h4 className="color-313131">
                                Patients
                              </h4>
                            </div>
                            <table className="w-100">
                              <tr className="thead_bg">
                                <th>MR No</th>
                                <th>Patient</th>
                                <th>Patient Site</th>
                                <th>Gender</th>
                                <th>Status</th>
                                <th>Action</th>
                              </tr>
                              <tr>
                                <td>812782</td>
                                <td>Sara Mahmood</td>
                                <td>F. B Area Clinic</td>
                                <td >Female</td>
                                <td >Waiting</td>
                                <td>
                                  <div className="btn_wrap">
                                    <button className="btn btn-primary _actionss">
                                      Cancel
                                    </button>
                                    <button className="btn btn-primary _actionss starttt">
                                      Cancel
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </div>
                        </Col>
                      </Row>
                    </Container>
                  </>
                )}
              </>
            )}
          </>
        </section>
      )}
    </div>
  );
}

export default Dashboard;
