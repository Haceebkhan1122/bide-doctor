import React, { useEffect, useState, useRef } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import "./profileUpdate.scss";
import "./../../uiComponents/ProfileSetup/Steps/Steps.scss";
import {
  Button,
  Form,
  Input,
  Select,
  Radio,
  Space,
  Popover,
  DatePicker,
} from "antd";
import { Label } from "evergreen-ui";
import infoIcon from "../../assets/images/png/info.png";
import { Container, Col, Row } from "react-bootstrap";
import editProfile from "../../assets/images/png/edit.png";

const { Option } = Select;
let index = 0;

const profileUpdate = (props) => {
  const [addname, setAddName] = useState("");
  const [showAddItem, setShowAddItem] = useState(false); // State to control the visibility of Add item field and button
  const [items, setItems] = useState([
    "Acne",
    "Diabetes",
    "Hypertension",
    "Other",
  ]);
  const inputRef = useRef(null);

  const handleConditionsChange = (value) => {
    setShowAddItem(!showAddItem);
    setShowAddItem(value.includes("Other"));
  };

  const onNameChange = (event) => {
    setAddName(event.target.value);
  };

  const addItem = (e) => {
    e.preventDefault();
    if (addname !== "Other") {
      // setItems([...items, name || `New item ${index++}`]);// Add new item at the end
      setItems([addname || `New item ${index++}`, ...items]); // Add new item at the beginning
    }
    setAddName("");
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
  };

  const { TextArea } = Input;
  const content = (
    <div>
      <p className="info">
        In case you don't make a selection, we will assign the most common
        <br></br> diseases related to your speciality to boost your visibility
        on our<br></br> platform.
      </p>
    </div>
  );

  return (
    <div className="pt-120 profile_update">
      <Container>
        <Row>
          <Col lg={12} className="mobile_center">
            <h2 className="mb-3">UPDATE PROFILE</h2>
            <div className="user_name mb-45">
              AB
              <button>
                {" "}
                <img src={editProfile}></img>
              </button>
            </div>
          </Col>
        </Row>
        <Row>
          <Col lg={12} className=" profile_tabs">
            <Tabs
              defaultActiveKey="about"
              id="uncontrolled-tab-example"
              className="mb-3"
            >
              <Tab eventKey="about" title="About">
                <h3 className="heading_profile mb-5">Basic Information</h3>
                <Row className="main_step_box">
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="id"
                      label="Doctor ID "
                      rules={[{ required: false }]}
                    >
                      <Input disabled value="ss" placeholder="345643" />
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="fullname"
                      label="Full Name* "
                      rules={[
                        { required: true, message: " Full name is required" },
                      ]}
                    >
                      <div className="d-flex selectBox box_dr_name">
                        <Select placeholder="Dr.">
                          <Option value="Male">Dr.</Option>
                          <Option value="Female">Prof.</Option>
                        </Select>
                        <Input placeholder="Khalid Farooq" />
                      </div>
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="phone"
                      label="Mobile Number*"
                      rules={[
                        { required: true, message: "Phone is required" },
                        {
                          pattern: /^\d+$/,
                          message:
                            "Phone number should only contain numeric values",
                        },
                        {
                          max: 11,
                          message: "Phone number cannot exceed 11 characters",
                        },
                      ]}
                    >
                      <Input
                        maxLength="11"
                        onKeyDown={(evt) => {
                          const allowedKeys = [
                            "Backspace",
                            "ArrowLeft",
                            "ArrowRight",
                            "Delete",
                          ];
                          if (
                            !/\d/.test(evt.key) &&
                            !allowedKeys.includes(evt.key)
                          ) {
                            evt.preventDefault();
                          }
                        }}
                        placeholder="0300-1234567"
                      />
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="assistantphone"
                      label="Assistant Mobile Number"
                      rules={[
                        { required: true, message: "Phone is required" },
                        {
                          pattern: /^\d+$/,
                          message:
                            "Phone number should only contain numeric values",
                        },
                        {
                          max: 11,
                          message: "Phone number cannot exceed 11 characters",
                        },
                      ]}
                    >
                      <Input
                        maxLength="11"
                        onKeyDown={(evt) => {
                          const allowedKeys = [
                            "Backspace",
                            "ArrowLeft",
                            "ArrowRight",
                            "Delete",
                          ];
                          if (
                            !/\d/.test(evt.key) &&
                            !allowedKeys.includes(evt.key)
                          ) {
                            evt.preventDefault();
                          }
                        }}
                        placeholder="Assistant Mobile Number"
                      />
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="email"
                      label="Email Address*"
                      rules={[
                        { required: true, message: "Email is required" },
                        { type: "email", message: "Invalid email format" },
                      ]}
                    >
                      <Input placeholder="Email Address*" />
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4}>
                    <Form.Item
                      name="dob"
                      label="Date of Birth*"
                      rules={[
                        {
                          required: true,
                          message: "Date of birth is required",
                        },
                      ]}
                    >
                      <DatePicker />
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4} className="selectBox">
                    <Form.Item
                      name="gender"
                      label="Gender*"
                      rules={[
                        {
                          required: true,
                          message: "Gender is required",
                        },
                      ]}
                    >
                      <Select placeholder="Select an option">
                        <Option value="Male">Male</Option>
                        <Option value="Female">Female</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4} className="selectBox">
                    <Form.Item
                      name="City"
                      label="City*"
                      rules={[
                        {
                          required: true,
                          message: "City is required",
                        },
                      ]}
                    >
                      <Select placeholder="Select City">
                        <Option value="Islamabad">Islamabad</Option>
                        <Option value="Ahmadpur East" id="Punjab">
                          Ahmadpur East
                        </Option>
                        <Option value="Ahmed Nager Chatha" id="Punjab">
                          Ahmed Nager Chatha
                        </Option>
                        <Option value="Ali Khan Abad" id="Punjab">
                          Ali Khan Abad
                        </Option>
                        <Option value="Alipur" id="Punjab">
                          Alipur
                        </Option>
                        <Option value="Arifwala" id="Punjab">
                          Arifwala
                        </Option>
                        <Option value="Attock" id="Punjab">
                          Attock
                        </Option>
                        <Option value="Bhera" id="Punjab">
                          Bhera
                        </Option>
                        <Option value="Bhalwal" id="Punjab">
                          Bhalwal
                        </Option>
                        <Option value="Bahawalnagar" id="Punjab">
                          Bahawalnagar
                        </Option>
                        <Option value="Bahawalpur" id="Punjab">
                          Bahawalpur
                        </Option>
                        <Option value="Bhakkar" id="Punjab">
                          Bhakkar
                        </Option>
                        <Option value="Burewala" id="Punjab">
                          Burewala
                        </Option>
                        <Option value="Chillianwala" id="Punjab">
                          Chillianwala
                        </Option>
                        <Option value="Chakwal" id="Punjab">
                          Chakwal
                        </Option>
                        <Option value="Chichawatni" id="Punjab">
                          Chichawatni
                        </Option>
                        <Option value="Chiniot" id="Punjab">
                          Chiniot
                        </Option>
                        <Option value="Chishtian" id="Punjab">
                          Chishtian
                        </Option>
                        <Option value="Daska" id="Punjab">
                          Daska
                        </Option>
                        <Option value="Darya Khan" id="Punjab">
                          Darya Khan
                        </Option>
                        <Option value="Dera Ghazi Khan" id="Punjab">
                          Dera Ghazi Khan
                        </Option>
                        <Option value="Dhaular" id="Punjab">
                          Dhaular
                        </Option>
                        <Option value="Dina" id="Punjab">
                          Dina
                        </Option>
                        <Option value="Dinga" id="Punjab">
                          Dinga
                        </Option>
                        <Option value="Dipalpur" id="Punjab">
                          Dipalpur
                        </Option>
                        <Option value="Faisalabad" id="Punjab">
                          Faisalabad
                        </Option>
                        <Option value="Ferozewala" id="Punjab">
                          Ferozewala
                        </Option>
                        <Option value="Fateh Jhang" id="Punjab">
                          Fateh Jang
                        </Option>
                        <Option value="Ghakhar Mandi" id="Punjab">
                          Ghakhar Mandi
                        </Option>
                        <Option value="Gojra" id="Punjab">
                          Gojra
                        </Option>
                        <Option value="Gujranwala" id="Punjab">
                          Gujranwala
                        </Option>
                        <Option value="Gujrat" id="Punjab">
                          Gujrat
                        </Option>
                        <Option value="Gujar Khan" id="Punjab">
                          Gujar Khan
                        </Option>
                        <Option value="Hafizabad" id="Punjab">
                          Hafizabad
                        </Option>
                        <Option value="Haroonabad" id="Punjab">
                          Haroonabad
                        </Option>
                        <Option value="Hasilpur" id="Punjab">
                          Hasilpur
                        </Option>
                        <Option value="Haveli Lakha" id="Punjab">
                          Haveli Lakha
                        </Option>
                        <Option value="Jatoi" id="Punjab">
                          Jatoi
                        </Option>
                        <Option value="Jalalpur" id="Punjab">
                          Jalalpur
                        </Option>
                        <Option value="Jattan" id="Punjab">
                          Jattan
                        </Option>
                        <Option value="Jampur" id="Punjab">
                          Jampur
                        </Option>
                        <Option value="Jaranwala" id="Punjab">
                          Jaranwala
                        </Option>
                        <Option value="Jhang" id="Punjab">
                          Jhang
                        </Option>
                        <Option value="Jhelum" id="Punjab">
                          Jhelum
                        </Option>
                        <Option value="Kalabagh" id="Punjab">
                          Kalabagh
                        </Option>
                        <Option value="Karor Lal Esan" id="Punjab">
                          Karor Lal Esan
                        </Option>
                        <Option value="Kasur" id="Punjab">
                          Kasur
                        </Option>
                        <Option value="Kamalia" id="Punjab">
                          Kamalia
                        </Option>
                        <Option value="Kamoke" id="Punjab">
                          Kamoke
                        </Option>
                        <Option value="Khanewal" id="Punjab">
                          Khanewal
                        </Option>
                        <Option value="Khanpur" id="Punjab">
                          Khanpur
                        </Option>
                        <Option value="Kharian" id="Punjab">
                          Kharian
                        </Option>
                        <Option value="Khushab" id="Punjab">
                          Khushab
                        </Option>
                        <Option value="Kot Addu" id="Punjab">
                          Kot Addu
                        </Option>
                        <Option value="Jauharabad" id="Punjab">
                          Jauharabad
                        </Option>
                        <Option value="Lahore" id="Punjab">
                          Lahore
                        </Option>
                        <Option value="Lalamusa" id="Punjab">
                          Lalamusa
                        </Option>
                        <Option value="Layyah" id="Punjab">
                          Layyah
                        </Option>
                        <Option value="Liaquat Pur" id="Punjab">
                          Liaquat Pur
                        </Option>
                        <Option value="Lodhran" id="Punjab">
                          Lodhran
                        </Option>
                        <Option value="Malakwal" id="Punjab">
                          Malakwal
                        </Option>
                        <Option value="Mamoori" id="Punjab">
                          Mamoori
                        </Option>
                        <Option value="Mailsi" id="Punjab">
                          Mailsi
                        </Option>
                        <Option value="Mandi Bahauddin" id="Punjab">
                          Mandi Bahauddin
                        </Option>
                        <Option value="Mian Channu" id="Punjab">
                          Mian Channu
                        </Option>
                        <Option value="Mianwali" id="Punjab">
                          Mianwali
                        </Option>
                        <Option value="Multan" id="Punjab">
                          Multan
                        </Option>
                        <Option value="Murree" id="Punjab">
                          Murree
                        </Option>
                        <Option value="Muridke" id="Punjab">
                          Muridke
                        </Option>
                        <Option value="Mianwali Bangla" id="Punjab">
                          Mianwali Bangla
                        </Option>
                        <Option value="Muzaffargarh" id="Punjab">
                          Muzaffargarh
                        </Option>
                        <Option value="Narowal" id="Punjab">
                          Narowal
                        </Option>
                        <Option value="Nankana Sahib" id="Punjab">
                          Nankana Sahib
                        </Option>
                        <Option value="Okara" id="Punjab">
                          Okara
                        </Option>
                        <Option value="Renala Khurd" id="Punjab">
                          Renala Khurd
                        </Option>
                        <Option value="Pakpattan" id="Punjab">
                          Pakpattan
                        </Option>
                        <Option value="Pattoki" id="Punjab">
                          Pattoki
                        </Option>
                        <Option value="Pir Mahal" id="Punjab">
                          Pir Mahal
                        </Option>
                        <Option value="Qaimpur" id="Punjab">
                          Qaimpur
                        </Option>
                        <Option value="Qila Didar Singh" id="Punjab">
                          Qila Didar Singh
                        </Option>
                        <Option value="Rabwah" id="Punjab">
                          Rabwah
                        </Option>
                        <Option value="Raiwind" id="Punjab">
                          Raiwind
                        </Option>
                        <Option value="Rajanpur" id="Punjab">
                          Rajanpur
                        </Option>
                        <Option value="Rahim Yar Khan" id="Punjab">
                          Rahim Yar Khan
                        </Option>
                        <Option value="Rawalpindi" id="Punjab">
                          Rawalpindi
                        </Option>
                        <Option value="Sadiqabad" id="Punjab">
                          Sadiqabad
                        </Option>
                        <Option value="Safdarabad" id="Punjab">
                          Safdarabad
                        </Option>
                        <Option value="Sahiwal" id="Punjab">
                          Sahiwal
                        </Option>
                        <Option value="Sangla Hill" id="Punjab">
                          Sangla Hill
                        </Option>
                        <Option value="Sarai Alamgir" id="Punjab">
                          Sarai Alamgir
                        </Option>
                        <Option value="Sargodha" id="Punjab">
                          Sargodha
                        </Option>
                        <Option value="Shakargarh" id="Punjab">
                          Shakargarh
                        </Option>
                        <Option value="Sheikhupura" id="Punjab">
                          Sheikhupura
                        </Option>
                        <Option value="Sialkot" id="Punjab">
                          Sialkot
                        </Option>
                        <Option value="Sohawa" id="Punjab">
                          Sohawa
                        </Option>
                        <Option value="Soianwala" id="Punjab">
                          Soianwala
                        </Option>
                        <Option value="Siranwali" id="Punjab">
                          Siranwali
                        </Option>
                        <Option value="Talagang" id="Punjab">
                          Talagang
                        </Option>
                        <Option value="Taxila" id="Punjab">
                          Taxila
                        </Option>
                        <Option value="Toba Tek Singh" id="Punjab">
                          Toba Tek Singh
                        </Option>
                        <Option value="Vehari" id="Punjab">
                          Vehari
                        </Option>
                        <Option value="Wah Cantonment" id="Punjab">
                          Wah Cantonment
                        </Option>
                        <Option value="Wazirabad" id="Punjab">
                          Wazirabad
                        </Option>

                        <Option value="Badin" id="Sindh">
                          Badin
                        </Option>
                        <Option value="Bhirkan" id="Sindh">
                          Bhirkan
                        </Option>
                        <Option value="Rajo Khanani" id="Sindh">
                          Rajo Khanani
                        </Option>
                        <Option value="Chak" id="Sindh">
                          Chak
                        </Option>
                        <Option value="Dadu" id="Sindh">
                          Dadu
                        </Option>
                        <Option value="Digri" id="Sindh">
                          Digri
                        </Option>
                        <Option value="Diplo" id="Sindh">
                          Diplo
                        </Option>
                        <Option value="Dokri" id="Sindh">
                          Dokri
                        </Option>
                        <Option value="Ghotki" id="Sindh">
                          Ghotki
                        </Option>
                        <Option value="Haala" id="Sindh">
                          Haala
                        </Option>
                        <Option value="Hyderabad" id="Sindh">
                          Hyderabad
                        </Option>
                        <Option value="Islamkot" id="Sindh">
                          Islamkot
                        </Option>
                        <Option value="Jacobabad" id="Sindh">
                          Jacobabad
                        </Option>
                        <Option value="Jamshoro" id="Sindh">
                          Jamshoro
                        </Option>
                        <Option value="Jungshahi" id="Sindh">
                          Jungshahi
                        </Option>
                        <Option value="Kandhkot" id="Sindh">
                          Kandhkot
                        </Option>
                        <Option value="Kandiaro" id="Sindh">
                          Kandiaro
                        </Option>
                        <Option value="Karachi" id="Sindh">
                          Karachi
                        </Option>
                        <Option value="Kashmore" id="Sindh">
                          Kashmore
                        </Option>
                        <Option value="Keti Bandar" id="Sindh">
                          Keti Bandar
                        </Option>
                        <Option value="Khairpur" id="Sindh">
                          Khairpur
                        </Option>
                        <Option value="Kotri" id="Sindh">
                          Kotri
                        </Option>
                        <Option value="Larkana" id="Sindh">
                          Larkana
                        </Option>
                        <Option value="Matiari" id="Sindh">
                          Matiari
                        </Option>
                        <Option value="Mehar" id="Sindh">
                          Mehar
                        </Option>
                        <Option value="Mirpur Khas" id="Sindh">
                          Mirpur Khas
                        </Option>
                        <Option value="Mithani" id="Sindh">
                          Mithani
                        </Option>
                        <Option value="Mithi" id="Sindh">
                          Mithi
                        </Option>
                        <Option value="Mehrabpur" id="Sindh">
                          Mehrabpur
                        </Option>
                        <Option value="Moro" id="Sindh">
                          Moro
                        </Option>
                        <Option value="Nagarparkar" id="Sindh">
                          Nagarparkar
                        </Option>
                        <Option value="Naudero" id="Sindh">
                          Naudero
                        </Option>
                        <Option value="Naushahro Feroze" id="Sindh">
                          Naushahro Feroze
                        </Option>
                        <Option value="Naushara" id="Sindh">
                          Naushara
                        </Option>
                        <Option value="Nawabshah" id="Sindh">
                          Nawabshah
                        </Option>
                        <Option value="Nazimabad" id="Sindh">
                          Nazimabad
                        </Option>
                        <Option value="Qambar" id="Sindh">
                          Qambar
                        </Option>
                        <Option value="Qasimabad" id="Sindh">
                          Qasimabad
                        </Option>
                        <Option value="Ranipur" id="Sindh">
                          Ranipur
                        </Option>
                        <Option value="Ratodero" id="Sindh">
                          Ratodero
                        </Option>
                        <Option value="Rohri" id="Sindh">
                          Rohri
                        </Option>
                        <Option value="Sakrand" id="Sindh">
                          Sakrand
                        </Option>
                        <Option value="Sanghar" id="Sindh">
                          Sanghar
                        </Option>
                        <Option value="Shahbandar" id="Sindh">
                          Shahbandar
                        </Option>
                        <Option value="Shahdadkot" id="Sindh">
                          Shahdadkot
                        </Option>
                        <Option value="Shahdadpur" id="Sindh">
                          Shahdadpur
                        </Option>
                        <Option value="Shahpur Chakar" id="Sindh">
                          Shahpur Chakar
                        </Option>
                        <Option value="Shikarpaur" id="Sindh">
                          Shikarpaur
                        </Option>
                        <Option value="Sukkur" id="Sindh">
                          Sukkur
                        </Option>
                        <Option value="Tangwani" id="Sindh">
                          Tangwani
                        </Option>
                        <Option value="Tando Adam Khan" id="Sindh">
                          Tando Adam Khan
                        </Option>
                        <Option value="Tando Allahyar" id="Sindh">
                          Tando Allahyar
                        </Option>
                        <Option value="Tando Muhammad Khan" id="Sindh">
                          Tando Muhammad Khan
                        </Option>
                        <Option value="Thatta" id="Sindh">
                          Thatta
                        </Option>
                        <Option value="Umerkot" id="Sindh">
                          Umerkot
                        </Option>
                        <Option value="Warah" id="Sindh">
                          Warah
                        </Option>

                        <Option value="Abbottabad" id="KPK">
                          Abbottabad
                        </Option>
                        <Option value="Adezai" id="KPK">
                          Adezai
                        </Option>
                        <Option value="Alpuri" id="KPK">
                          Alpuri
                        </Option>
                        <Option value="Akora Khattak" id="KPK">
                          Akora Khattak
                        </Option>
                        <Option value="Ayubia" id="KPK">
                          Ayubia
                        </Option>
                        <Option value="Banda Daud Shah" id="KPK">
                          Banda Daud Shah
                        </Option>
                        <Option value="Bannu" id="KPK">
                          Bannu
                        </Option>
                        <Option value="Batkhela" id="KPK">
                          Batkhela
                        </Option>
                        <Option value="Battagram" id="KPK">
                          Battagram
                        </Option>
                        <Option value="Birote" id="KPK">
                          Birote
                        </Option>
                        <Option value="Chakdara" id="KPK">
                          Chakdara
                        </Option>
                        <Option value="Charsadda" id="KPK">
                          Charsadda
                        </Option>
                        <Option value="Chitral" id="KPK">
                          Chitral
                        </Option>
                        <Option value="Daggar" id="KPK">
                          Daggar
                        </Option>
                        <Option value="Dargai" id="KPK">
                          Dargai
                        </Option>
                        <Option value="Darya Khan" id="KPK">
                          Darya Khan
                        </Option>
                        <Option value="Dera Ismail Khan" id="KPK">
                          Dera Ismail Khan
                        </Option>
                        <Option value="Doaba" id="KPK">
                          Doaba
                        </Option>
                        <Option value="Dir" id="KPK">
                          Dir
                        </Option>
                        <Option value="Drosh" id="KPK">
                          Drosh
                        </Option>
                        <Option value="Hangu" id="KPK">
                          Hangu
                        </Option>
                        <Option value="Haripur" id="KPK">
                          Haripur
                        </Option>
                        <Option value="Karak" id="KPK">
                          Karak
                        </Option>
                        <Option value="Kohat" id="KPK">
                          Kohat
                        </Option>
                        <Option value="Kulachi" id="KPK">
                          Kulachi
                        </Option>
                        <Option value="Lakki Marwat" id="KPK">
                          Lakki Marwat
                        </Option>
                        <Option value="Latamber" id="KPK">
                          Latamber
                        </Option>
                        <Option value="Madyan" id="KPK">
                          Madyan
                        </Option>
                        <Option value="Mansehra" id="KPK">
                          Mansehra
                        </Option>
                        <Option value="Mardan" id="KPK">
                          Mardan
                        </Option>
                        <Option value="Mastuj" id="KPK">
                          Mastuj
                        </Option>
                        <Option value="Mingora" id="KPK">
                          Mingora
                        </Option>
                        <Option value="Nowshera" id="KPK">
                          Nowshera
                        </Option>
                        <Option value="Paharpur" id="KPK">
                          Paharpur
                        </Option>
                        <Option value="Pabbi" id="KPK">
                          Pabbi
                        </Option>
                        <Option value="Peshawar" id="KPK">
                          Peshawar
                        </Option>
                        <Option value="Saidu Sharif" id="KPK">
                          Saidu Sharif
                        </Option>
                        <Option value="Shorkot" id="KPK">
                          Shorkot
                        </Option>
                        <Option value="Shewa Adda" id="KPK">
                          Shewa Adda
                        </Option>
                        <Option value="Swabi" id="KPK">
                          Swabi
                        </Option>
                        <Option value="Swat" id="KPK">
                          Swat
                        </Option>
                        <Option value="Tangi" id="KPK">
                          Tangi
                        </Option>
                        <Option value="Tank" id="KPK">
                          Tank
                        </Option>
                        <Option value="Thall" id="KPK">
                          Thall
                        </Option>
                        <Option value="Timergara" id="KPK">
                          Timergara
                        </Option>
                        <Option value="Tordher" id="KPK">
                          Tordher
                        </Option>

                        <Option value="Awaran" id="Balochistan">
                          Awaran
                        </Option>
                        <Option value="Barkhan" id="Balochistan">
                          Barkhan
                        </Option>
                        <Option value="Chagai" id="Balochistan">
                          Chagai
                        </Option>
                        <Option value="Dera Bugti" id="Balochistan">
                          Dera Bugti
                        </Option>
                        <Option value="Gwadar" id="Balochistan">
                          Gwadar
                        </Option>
                        <Option value="Harnai" id="Balochistan">
                          Harnai
                        </Option>
                        <Option value="Jafarabad" id="Balochistan">
                          Jafarabad
                        </Option>
                        <Option value="Jhal Magsi" id="Balochistan">
                          Jhal Magsi
                        </Option>
                        <Option value="Kacchi" id="Balochistan">
                          Kacchi
                        </Option>
                        <Option value="Kalat" id="Balochistan">
                          Kalat
                        </Option>
                        <Option value="Kech" id="Balochistan">
                          Kech
                        </Option>
                        <Option value="Kharan" id="Balochistan">
                          Kharan
                        </Option>
                        <Option value="Khuzdar" id="Balochistan">
                          Khuzdar
                        </Option>
                        <Option value="Killa Abdullah" id="Balochistan">
                          Killa Abdullah
                        </Option>
                        <Option value="Killa Saifullah" id="Balochistan">
                          Killa Saifullah
                        </Option>
                        <Option value="Kohlu" id="Balochistan">
                          Kohlu
                        </Option>
                        <Option value="Lasbela" id="Balochistan">
                          Lasbela
                        </Option>
                        <Option value="Lehri" id="Balochistan">
                          Lehri
                        </Option>
                        <Option value="Loralai" id="Balochistan">
                          Loralai
                        </Option>
                        <Option value="Mastung" id="Balochistan">
                          Mastung
                        </Option>
                        <Option value="Musakhel" id="Balochistan">
                          Musakhel
                        </Option>
                        <Option value="Nasirabad" id="Balochistan">
                          Nasirabad
                        </Option>
                        <Option value="Nushki" id="Balochistan">
                          Nushki
                        </Option>
                        <Option value="Panjgur" id="Balochistan">
                          Panjgur
                        </Option>
                        <Option value="Pishin Valley" id="Balochistan">
                          Pishin Valley
                        </Option>
                        <Option value="Quetta" id="Balochistan">
                          Quetta
                        </Option>
                        <Option value="Sherani" id="Balochistan">
                          Sherani
                        </Option>
                        <Option value="Sibi" id="Balochistan">
                          Sibi
                        </Option>
                        <Option value="Sohbatpur" id="Balochistan">
                          Sohbatpur
                        </Option>
                        <Option value="Washuk" id="Balochistan">
                          Washuk
                        </Option>
                        <Option value="Zhob" id="Balochistan">
                          Zhob
                        </Option>
                        <Option value="Ziarat" id="Balochistan">
                          Ziarat
                        </Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col lg={4} md={4} className="selectBox">
                    <Form.Item
                      name="experiance"
                      label="Total Experience in years*"
                      rules={[
                        {
                          required: true,
                          message: "Experience is required",
                        },
                      ]}
                    >
                      <Select placeholder="Select an option">
                        <Option value="1year">1</Option>
                        <Option value="2year">2</Option>
                        <Option value="3year">3</Option>
                        <Option value="4year">4</Option>
                        <Option value="5year">5</Option>
                        <Option value="6year">6</Option>
                        <Option value="7year">7</Option>
                        <Option value="8year">8</Option>

                        <Option value="9year">9</Option>
                        <Option value="10year">10</Option>
                        <Option value="11year">11</Option>
                        <Option value="12year">12</Option>
                        <Option value="13year">13</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
                <h3 className="heading_profile mb-5">Practice Details</h3>
                <Row className="main_step_box">
                  <Col lg={12} md={12}>
                    <Form.Item
                      name="about"
                      label="About me"
                      className="textarea_style"
                    >
                      <TextArea
                        rows={4}
                        placeholder="Please share a brief bio to provide additional information about yourself..."
                      />
                    </Form.Item>
                  </Col>
                  <Col lg={6} md={6}>
                    <Form.Item
                      name="pmdc"
                      label="PMDC Number  (Not mandatory for certain specialties)* "
                      rules={[
                        { required: true, message: "PMDC number is required" },
                        {
                          pattern: /^\d+$/,
                          message:
                            "PMDC number should only contain numeric values",
                        },
                        {
                          max: 13,
                          message: "PMDC number cannot exceed 13 characters",
                        },
                      ]}
                    >
                      <Input
                        maxLength="13"
                        onKeyDown={(evt) => {
                          const allowedKeys = [
                            "Backspace",
                            "ArrowLeft",
                            "ArrowRight",
                            "Delete",
                          ];
                          if (
                            !/\d/.test(evt.key) &&
                            !allowedKeys.includes(evt.key)
                          ) {
                            evt.preventDefault();
                          }
                        }}
                        placeholder="Enter PMDC number"
                      />
                    </Form.Item>
                  </Col>
                  <Col lg={6} md={6}></Col>
                  <Col lg={6} md={6} className="selectBox ">
                    <Form.Item
                      name="speciality"
                      label="Select your speciality*"
                      rules={[
                        {
                          required: true,
                          message: "Speciality is required",
                        },
                      ]}
                    >
                      <Select placeholder="Ent Specialist">
                        <Option value="rheumatologist">Rheumatologist</Option>
                        <Option value="gynecologist">gynecologist</Option>
                        <Option value="orthopedic">orthopedic</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col lg={6} md={6} className="selectBox condition_box ">
                    <Form.Item
                      name="conditions"
                      rules={[
                        {
                          required: false,
                          message: "conditions is required",
                        },
                      ]}
                    >
                      <Label>
                        Select conditions you treat{" "}
                        <div className="popover_box1">
                          <Popover
                            content={content}
                            placement="topLeft"
                            overlayClassName="popover_box"
                          >
                            <img
                              src={infoIcon}
                              className="img-fluid"
                              alt="info"
                            ></img>
                          </Popover>
                        </div>
                      </Label>

                      <Select
                        mode="multiple"
                        placeholder="Select conditions"
                        className="select_des"
                        onChange={handleConditionsChange} // Call the handleConditionsChange function on conditions change
                        dropdownClassName="dropdown_box_checkbox"
                        dropdownRender={(menu) => (
                          <>
                            {menu}

                            {showAddItem && ( // Show Add item field and button only when showAddItem is true
                              <Space
                                style={{ padding: "0 8px 4px" }}
                                className="add_item"
                              >
                                <Input
                                  placeholder="Enter condition you treat"
                                  ref={inputRef}
                                  value={addname}
                                  onChange={onNameChange}
                                  className="textfield"
                                />
                                <Button
                                  type="text"
                                  onClick={addItem}
                                  className={addname ? "activebtn" : ""}
                                >
                                  Add
                                </Button>
                              </Space>
                            )}
                          </>
                        )}
                        options={items.map((item) => ({
                          label: item,
                          value: item,
                        }))}
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </Tab>
              <Tab eventKey="qualification" title="QUALIFICATIONS">
                Tab content for Profile
              </Tab>
              <Tab eventKey="consultationdetails" title="Consultation Details">
                Tab content for Contact
              </Tab>
            </Tabs>
          </Col>
        </Row>
      </Container>
    </div>
  );
};
export default profileUpdate;
