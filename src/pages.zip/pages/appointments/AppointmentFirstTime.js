import React, { useEffect, useState, useRef } from "react";


import {
  Button,
  Form,
  Input,
  Modal,
  Popconfirm,
  Select,
  Switch,
  Checkbox,
} from "antd";
import { Col, Collapse, Container, Row, Table } from "react-bootstrap";
import MedCancelCard from "../../uiComponents/card/medCancelCard/MedCancelCard";
import {
  HeadingDesc,
  HeadingDescSmall,
  HeadingDescVsmall,
  HeadingWithSpaceLarge,
} from "../../uiComponents/Headings";
import StickyTab from "../../uiComponents/stickyTab/StickyTab";
import { TableComponent } from "../../uiComponents/tableComponent";
import deleteIconPink from "../../assets/images/svg/delete_icon_pink.svg";
import notallow from "../../assets/images/svg/notallow.svg";
import calendar01 from "../../assets/images/svg/calendar01.svg";
import arrowdropdown from "../../assets/images/svg/dropdown-icon.svg";
import fileSrc from "../../assets/images/svg/fileShape.svg";
import delete1 from "../../assets/images/svg/delete.svg";
import fileIcon from "../../assets/images/png/view.png";
import { DatePicker, Space } from 'antd';

import {
  FiArrowRightCircle,
  FiChevronRight,
  FiCircle,
  FiCheckCircle,
} from "react-icons/fi";
import { useHistory, useLocation, useParams } from "react-router-dom";
import {
  getAppointmentData,
  getDiseases,
  getMedicine,
  getLab,
  postConsult,
  getVitalScan,
} from "./redux/thunk";
import { useAppDispatch, useAppSelector } from "./../../redux/hooks";
import arrowDownload from "../../assets/images/svg/arrow-download-circle.svg";
import logo from "../../assets/images/svg/meri-sehat-logo.svg";
import logoMob from "../../assets/images/svg/logo-mobile.svg";
import featuredDoc from "../../assets/images/png/featured_doc.png";
import drSaad from "../../assets/images/png/dr-saad.jpg";
import FeaturedTick from "../../assets/images/png/featured_doc.png";
import DrPicture from "../../assets/images/png/dr-saad.jpg";
import LoaderTimer from "../../assets/images/gif/loading_spinner.gif";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  selectAppointmentData,
  selectDiseases,
  selectMedicine,
  selectLabs,
  selectMedical,
  selectAppointmentToken,
  selectVitalScan,
  selectInstantMedical,
  selectAppointmentDataSuccess,
  selectMedicineLoading,
  selectLabLoading,
} from "./redux/slice";
import "./Appointments.scss";
import LabForm from "../../uiComponents/form/LabForm";
import MedForm from "../../uiComponents/form/MedForm";
import Agora from "../../uiComponents/agora/Agora";
import { ToastContainer, toast } from "react-toastify";
import Countdown from "react-countdown";
// import FsLightbox from 'fslightbox-react';
import "yet-another-react-lightbox/styles.css";
import { downloadPrescription, getAge } from "../../helpers/utilityHelper";
import { RouterPrompt } from "../../uiComponents/RouterPrompt";
import disableConsultation from "../../assets/images/svg/instant-disable-modal.svg";
import { TabList, TabPanel, TabContext } from "@mui/lab";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import RemovePre from "../../assets/images/svg/removePre.svg";
import EditPre from "../../assets/images/svg/EditPre.svg";
import { useEffectOnce } from "react-use";
import API from "../../utils/customAxios";
import { selectDashboard } from "../dashboard/redux/slice";
import { getDashboardDetails } from "../dashboard/redux/thunk";
import { acquireApi, startApi, stopApi } from "../../utils/agoraEndpoints";
import axios from "axios";
import "./appointmentFirstTime.css";
import { AiOutlineFile } from "react-icons/ai";
import AgoraRTM from "agora-rtm-sdk";
import TablePreviousHistory from "../../uiComponents/tableComponent/TablePreviousHistory/TablePreviousHistory";
import TabItem from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Nav from "react-bootstrap/Nav";
import moment from "moment";
import Accordion from "react-bootstrap/Accordion";
import { isMobile } from "react-device-detect";
import smilyFace from "../../assets/images/png/smily.png";
import stressFace from "../../assets/images/png/stress-emojy.png";
import closeTable from "../../assets/images/png/close-table.png";
import lowStress from "../../assets/images/png/low-stress.png";
import normalStress from "../../assets/images/png/normal-stress.png";
import highStress from "../../assets/images/png/high-stress.png";
import { isJsonString, isProduction } from "../../utils/helperFunctions";
import { getUserId } from "../../helpers/authHelper";
import Cookies from "js-cookie";
import Loader from "../../uiComponents/loader/Loader";
import Agoraa from "../../uiComponents/agora/Agoraa";
import { InsulinForm } from "../../uiComponents/form/InsulinForm";
import PersonalHistory from "../../uiComponents/form/PersonalHistory";
import MedicalHistory from "../../uiComponents/form/MedicalHistory";
import LabsReport from "../../uiComponents/form/LabsReport";
import Vitals from "../../uiComponents/form/Vitals";
import DiabetesHis from "../../uiComponents/form/DiabetesHis";

let arr = new Set();

function AppointmentFirstTime(props) {



  const doctorId = getUserId();

  let stagingName = `S${doctorId}`;
  let prodName = `L${doctorId}`;

  let firstPrefix = process.env.REACT_APP_BASE_URL?.includes("staging")
    ? stagingName
    : prodName;

  const history = useHistory();
  const params = useParams();
  const textareaRef = useRef();

  const [tabValue, setTabValue] = React.useState("1");
  const [tabValue1, setTabValue1] = React.useState("11");
  const [tabSwitchState, setTabSwitchState] = useState(0);
  const [rtmToken, setRtmToken] = useState("");
  const handleChangeTabs = (event, newValue) => {
    setTabValue1(newValue);

  };
  const handleTabs = (event, newValue) => {
    if (tabSwitchState === 1 && newValue === "2") {
    } else if (tabSwitchState === 2 && newValue === "1") {
    } else {
      setTabValue(newValue);
    }
  };

  const dispatch = useAppDispatch();
  const location = useLocation();
  const selectDashboardDetails = useAppSelector(selectDashboard);

  if (location?.state?.user_id) {
    sessionStorage.setItem("user_id", location?.state?.user_id);
  }

  if (location?.state?.visit_count) {
    sessionStorage.setItem("visit_count", location?.state?.visit_count);
  }

  const AppointmentData = useAppSelector(selectAppointmentData);
  const vitalScan = useAppSelector(selectVitalScan);
  const conditions = useAppSelector(selectDiseases);
  const medicine = useAppSelector(selectMedicine);
  const medicineLoading = useAppSelector(selectMedicineLoading);
  const labLoading = useAppSelector(selectLabLoading);
  const labs = useAppSelector(selectLabs);
  // const medical = useAppSelector(selectMedical);
  const medical = useAppSelector(selectInstantMedical);
  const [appForm] = Form.useForm();
  const appointmentToken = useAppSelector(selectAppointmentToken);
  // console.log(location);
  let id = params.id;
  let user_id = sessionStorage.getItem("user_id");
  let visit_count = sessionStorage.getItem("visit_count");
  const [startCall, setStartCall] = useState(false);
  const [config, setConfig] = useState(null);
  const [toggler, setToggler] = useState(false);
  const [toggler1, setToggler1] = useState(false);
  const [loader, setLoader] = useState(false);
  const [note, setNote] = useState("");
  const [gnote, setGNote] = useState("");
  const [med, setMed] = useState([]);
  const [cond, setCond] = useState([]);
  const [editMedicineStatus, setEditMedicineStatus] = useState(false);
  const [editMedicine, setEditMedicine] = useState();
  const [patient, setPatient] = useState({
    name: "",
    age: "",
    gender: "",
    reason: "",
    prescription: "",
    previous_consultation: "",
  });
  const [medData, setMedData] = useState([]);
  const [medTable, setMedTable] = useState([]);
  const [vitalTable, setVitalTable] = useState([]);
  const [medicalRec, setMedicalRec] = useState([]);
  const [recFiles, setRecFiles] = useState([]);
  const [prevData, setPrevData] = useState([]);
  const [timeRem, setTimeRem] = useState(0);
  const [prescribeData, setPrescribeData] = useState([]);
  const [count, setCount] = useState(0);
  const [modal1Visible, setModal1Visible] = useState(false);
  const [modal2Visible, setModal2Visible] = useState(false);
  const [modal3Visible, setModal3Visible] = useState(false);
  const [modal4Visible, setModal4Visible] = useState(false);
  const [endAnnounced, setendAnnounced] = useState(false);
  const [blockUserExit, setBlockUserExit] = useState(false);
  const [formValues, setFormValues] = useState({});
  const { Option } = Select;
  const { TextArea } = Input;
  const [mobile, setMobile] = useState(false);
  const [writePrescriptionInfo, setWritePrescriptionInfo] = useState([]);
  const [isOnline, setIsOnline] = useState(true);
  const [errorPrescription, setErrorPrescription] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [channelToken, setChannelToken] = useState("");
  const [resourceId, setResourceId] = useState("");
  const [stopId, setStopId] = useState("");
  const [instantMedicalRecords, setInstantMedicalRecords] = useState([]);
  const [prev_consultation, setPrevConsultation] = useState([]);
  const [appointmentCompleted, setAppointmentCompleted] = useState(false);
  const [shouldDispatchMedicine, setShouldDispatchMedicine] = useState(false);
  const [pendingAppointments, setPendingAppointments] = useState(false);
  const [userCity, setUserCity] = useState("");
  const [activeTab, setActiveTab] = useState("");

  const [startNextConsultation, setStartNextConsultation] = useState(false);
  const [viewSingleReport, setViewSingleReport] = useState(false);
  const [viewSinglePresc, setViewSinglePresc] = useState(false);
  const [viewSingleReportFile, setViewSingleReportFile] = useState();
  const [modal2Open, setModal2Open] = useState(false);
  const [modal2OpenData, setModal2OpenData] = useState();

  const [csvLoading, setCsvLoading] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [showPrevConsultationModal, setShowPrevConsultationModal] = useState();
  const [completeAppointmentLoader, setCompleteAppointmentLoader] =
    useState(false);
  const [cancelAppointmentLoader, setCancelAppointmentLoader] = useState(false);
  const [showAddDiseaseBtn, setShowAddDiseaseBtn] = useState(false);
  const [shouldDispatchDiseases, setShouldDispatchDiseases] = useState(false);
  const [addDiseaseLoader, setAddDiseaseLoader] = useState(false);
  const [addMedicineLoader, setAddMedicineLoader] = useState(false);
  const [addLabLoader, setAddLabLoader] = useState(false);
  const [shouldDispatchLabs, setShouldDispatchLabs] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [downloadLoader, setDownloadLoader] = useState(false);
  const [downloadPastUrl, setDownloadPastUrl] = useState("");
  const [patientQueueCount, setPatientQueueCount] = useState(null);
  const [mainTabs, setMainTabs] = useState(11);




  const diseaseRef = useRef();

  const [key, setKey] = useState("home");

  // console.log(location?.search?.split('?'));
  useEffect(() => {
    setLoader(false);
    // dispatch(getMedicalRecord(user_id));
    // dispatch(getInstantMedicalRecord(1035));
    if (id) {
      dispatch(getAppointmentData(id));
    }

    dispatch(getVitalScan(user_id));
    dispatch(getMedicine());
    dispatch(getLab());
    dispatch(getDiseases());
    if (typeof window !== "undefined") {
      if (window.innerWidth < 600) {
        setMobile(true);
      }
    }
  }, [id]);

  // useEffect(() => {
  //   (async() => {
  //     const response = await API.get(`/generate-agora-rtm-token`);

  //     if (response?.data?.code === 200) {
  //       setRtmToken(response?.data?.data?.token);
  //     }
  //   })()
  // }, [])

  useEffect(() => {
    if (shouldDispatchDiseases === true) {
      dispatch(getDiseases());
    }
  }, [shouldDispatchDiseases]);

  useEffect(() => {
    if (shouldDispatchLabs === true) {
      dispatch(getLab());
      setShouldDispatchLabs(false);
    }
  }, [shouldDispatchLabs]);

  useEffect(() => {
    (async () => {
      try {
        const response = await API.get(
          `/generate-agora-link?appointment_id=${params.id}`
        );

        if (response?.data?.code === 200) {
          setChannelName(response?.data?.data?.channel_name);
          setChannelToken(response?.data?.data?.agora_token);
        }
      } catch (error) {
        // console.log(error, 'agorrerror');
      }
    })();
  }, [channelName]);


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await API.get('/doctor/patient-count');

        if (response?.data?.code === 200) {
          setPatientQueueCount(response.data?.data);
        }
      } catch (error) {
        // Handle the error here
        console.error('Error fetching patient count:', error);
      }
    };

    // Call fetchData immediately and then every 5 seconds
    fetchData();
    const intervalId = setInterval(fetchData, 15000);

    // Clean up the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []);



  useEffect(() => {
    if (channelName && isProduction()) {
      (async () => {
        const body = {
          cname: channelName,
          uid: params?.id?.toString(),
          clientRequest: {
            resourceExpiredHour: 24,
            scene: 0,
          },
        };

        const customerKey = process.env.REACT_APP_AGORA_CUSTOMER_KEY;
        const customerSecret = process.env.REACT_APP_AGORA_CUSTOMER_SECRET;

        const response = await axios.post(acquireApi, body, {
          auth: {
            username: customerKey,
            password: customerSecret,
          },
        });

        if (response?.status === 200) {
          const startAgoraAPI = startApi(response?.data?.resourceId);

          const payload = {
            cname: channelName,
            uid: params?.id?.toString(),
            clientRequest: {
              token: channelToken,
              recordingConfig: {
                // https://docs.agora.io/en/cloud-recording/reference/rest-api/start#recording-configuration
                maxIdleTime: 120,
                streamTypes: 2,
                audioProfile: 1,
                channelType: 0, //used for communication. if live broadcast, set to 1
                videoStreamType: 0,
                transcodingConfig: {
                  width: 640,
                  height: 480,
                  fps: 30,
                  bitrate: 600,
                  mixedVideoLayout: 1,
                },
              },

              recordingFileConfig: {
                avFileType: ["hls", "mp4"],
              },
              storageConfig: {
                vendor: 1, //Here 1 means AWS S3
                region: 8, // AP_SOUTHEAST_1
                bucket: "agora-recording-s",
                accessKey: process.env.REACT_APP_AWS_ACCESS_KEY,
                secretKey: process.env.REACT_APP_AWS_SECRET_ACCESS_KEY,
                fileNamePrefix: [firstPrefix, params?.id?.toString()],
              },
            },
          };
          try {
            const res = await axios.post(startAgoraAPI, payload, {
              auth: {
                username: customerKey,
                password: customerSecret,
              },
            });

            setResourceId(res?.data?.resourceId);
            setStopId(res?.data?.sid);
          } catch (error) {
            // console.log(error);
          }
        }
      })();
    }
  }, [channelName]);

  useEffectOnce(() => {
    dispatch(getDashboardDetails());
  });

  useEffect(() => {
    let interval = setInterval(async () => {
      const res = await API.get(`/instant-medical-record?user_id=${user_id}`);

      setMedicalRec(res?.data?.data);
    }, 10000);

    return function () {
      clearInterval(interval);
    };
  }, []);



  useEffect(() => {
    setVitalTable(vitalScan?.data);
  }, [vitalScan]);

  // useEffect(() => {
  //   setMedicalRec(medical?.data)
  // }, [medical]);

  useEffect(() => {
    window.addEventListener("unload", function (e) {
      // console.log('cancelled appointment');
    });
  }, []);

  useEffect(() => {
    if (AppointmentData?.data) {
      setUserCity(AppointmentData?.data?.user?.city);

      let data = {};
      data.patient = AppointmentData?.data?.user;
      data.reason = AppointmentData?.data?.reason;
      data.type = AppointmentData?.data?.type;
      data.prescription = AppointmentData?.data?.prescription;
      data.previous_consultation = AppointmentData?.data?.previous_consultation;

      setActiveTab(AppointmentData?.data?.previous_consultation?.[0]?.id);

      axios
        .get(
          `${process.env.REACT_APP_BASE_URL}/patient-info?user_id=${user_id}`,
          {
            headers: {
              // 'user-id': AppointmentData?.data?.user_id
              Authorization: Cookies.get("token"),
            },
          }
        )
        .then((res) => {
          // console.log(res, 'promise')
          setPatient({
            name: res?.data?.data?.name,
            age: getAge(res?.data?.data?.date_of_birth),
            gender: res?.data?.data?.gender,
            reason: data?.reason,
            type: AppointmentData?.data?.type,
            prescription: data?.prescription,
            previous_consultation: AppointmentData?.data?.previous_consultation,
            doctorName: AppointmentData?.data?.doctor?.name,
          });
        });

      setStartCall(data.type == "in-person" ? false : true);
      setLoader(true);
    }

    if (AppointmentData?.data?.remaining_time) {
      let currentDateTime = new Date();
      setTimeRem(
        new Date(
          currentDateTime.getTime() +
          parseInt(AppointmentData?.data?.remaining_time) * 1000
        )
      );
      // setTimeRem(new Date(currentDateTime.getTime() + parseInt(9400) * 1000));
    }
  }, [AppointmentData]);

  // const ErrorNull = () => {
  //   setErrorPrescription('')
  // }

  function writePrescription(e) {
    setErrorPrescription("");
    e.preventDefault();
    if (textareaRef.current.value === "") {
      setErrorPrescription("Field cannot be left empty");
    }

    if (textareaRef.current.value.length < 5) {
      setErrorPrescription("Prescription cannot be less than 5 characters");
    } else {
      setWritePrescriptionInfo([
        ...writePrescriptionInfo,
        textareaRef.current.value,
      ]);
      textareaRef.current.value = "";
    }
  }

  function removeWrittenPrescription(e, pres) {
    let filtered = writePrescriptionInfo.filter((info) => info !== pres);
    setWritePrescriptionInfo(filtered);
  }

  function editPrescriptionInfo(e, pres) {
    textareaRef.current.value = pres;

    let filtered = writePrescriptionInfo.filter((info) => info !== pres);
    setWritePrescriptionInfo(filtered);
  }

  function activeListHandler(e, elementId) {
    setBlockUserExit(false);

    const element = document.querySelector(elementId);
    const yOffset = -140;
    const y =
      element.getBoundingClientRect().top + window.pageYOffset + yOffset;

    if (element) {
      // element.scrollIntoView({ behavior: 'smooth', alignToTop: true, block: "nearest" });
      window.scrollTo({ top: y, behavior: "smooth" });
    }

    setTimeout(() => {
      setBlockUserExit(false);
    }, 4000);
  }

  // function consultationFinishedHandler() {
  //   const button = document.querySelector(".submit-btn-completed");

  //   button.click();
  // }

  console.log(patient.previous_consultation.length, 'lol')


  const handleDelete = (key, data, change) => {
    const newData = data?.filter((item) => item.key !== key);
    setPrescribeData(newData);
    change(newData);
  };

  async function downloadPastPrescription(e, url) {
    setDownloadLoader(true);
    fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': Cookies.get("token"),
        'Access-Control-Allow-Origin': '*'
      },
    })
      .then(response => response.blob())
      .then(response => {
        const blob = new Blob([response], { type: 'application/pdf' });
        const downloadUrl = URL.createObjectURL(blob);
        setDownloadLoader(false);
        const a = document.createElement("a");
        a.href = downloadUrl;
        a.download = "file.pdf";
        document.body.appendChild(a);
        a.click();
      })
      .catch((err) => {
        console.log({ err })
      })
  }

  let medHeader = [
    { title: "Medicine", dataIndex: "medicine" },
    { title: "Dosage", dataIndex: "dosage" },
    { title: "Frequency", dataIndex: "per_day" },
    { title: "Duration", dataIndex: "number_of_days" },
    { title: "Instruction", dataIndex: "is_after_meal" },
    {
      title: "",
      dataIndex: "buttons",
      render: (_, record) => (
        <div className="flex_start">
          {/* <a>
              <img src={editIConGreen} alt="edit"></img>
            </a> */}
          <Popconfirm
            title="Sure to delete?"
            onConfirm={() => {
              handleDelete(record.key, medData2, setMedTable);
            }}
          >
            <a>
              <img src={deleteIconPink} alt="delete"></img>
            </a>
          </Popconfirm>
        </div>
      ),
    },
  ];

  let vitalHeader = [
    { title: "Date", dataIndex: "date" },
    { title: "Heart Rate", dataIndex: "heart_rate" },
    { title: "Respiratory Rate", dataIndex: "respiratory_rate" },
    { title: "Blood Pressure", dataIndex: "blood_pressure" },
    { title: "Stress Level", dataIndex: "stress_level" },
    { title: "SDNN", dataIndex: "sdnn" },
    { title: "SPO2", dataIndex: "spo2" },
  ];

  let previousConsultationHeader = [
    { title: "Date", dataIndex: "date" },
    {
      title: "Prescription",
      dataIndex: "prescription",
      render(text, record) {
        // console.log(record, "record")

        return {
          children: (
            <div onClick={(e) => downloadPastPrescription(e, record?.downloadUrl)}>
              {" "}
              {record?.prescription}{" "}
            </div>
          ),
        };
      },
    },
  ];

  let medRecordHeader = [
    { title: "Date", dataIndex: "med_rec_date" },
    {
      title: "Records",
      dataIndex: "buttons",
      render(text, record) {
        // console.log(text, "zain");
        let files = [];
        let first = text?.[0]?.file;
        text?.map((f) => {
          files.push({ src: f?.file });
        });

        const slides = [
          // {
          //   src: first,
          //   width: "100%",
          //   height: "100%",
          //   srcSet: files
          // }
          files,
        ];
        let idd = record?.key;
        return {
          children: (
            <>
              <div className="row d-block medicalRecordBox _flex_start">
                <div>
                  {text?.length ? (
                    <p className="reportsFor">
                      Reports for{" "}
                      {AppointmentData?.data?.doctor?.prefix
                        ? `${AppointmentData?.data?.doctor?.prefix}. ${AppointmentData?.data?.doctor?.name}`
                        : AppointmentData?.data?.doctor?.name}
                    </p>
                  ) : null}
                </div>
                {text?.map((item, index) => (
                  <>
                    <a
                      key={index}
                      className="consult_now fs-16 text-decoration-none col-6 justify-content-start"
                      onClick={() => window.open(item?.file, "_blank")}
                    >
                      {/* <a className="consult_now" > */}
                      {/* <FiArrowRightCircle className="arrow_black" /> */}
                      <AiOutlineFile />
                      <img src={fileSrc} alt="" />
                      <p className="black_text text-capitalize ms-2">
                        {/* {cutFromMiddle(item?.filename)}{" "} */}
                        {item?.filename}
                      </p>
                    </a>

                    {/* {toggler1 && <LightboxModal id={idd} files={files} toggler1={toggler1} setToggler1={setToggler1} />} */}
                  </>
                ))}
              </div>
            </>
          ),
        };
      },
    },
    { title: "", dataIndex: "", className: "w-40" },
  ];

  let prescribeHeader = [
    { title: "Lab Test", dataIndex: "lab_test" },
    {
      title: "",
      dataIndex: "buttons",

      render: (_, record) => (
        <div className="flex_start">
          {/* <a>
            <img src={editIConGreen} alt="edit"></img>
          </a> */}
          <Popconfirm
            title="Sure to delete?"
            onConfirm={() => {
              handleDelete(record.key, prescribeData, setPrescribeData);
            }}
          >
            <a>
              <img src={deleteIconPink} alt="delete"></img>
            </a>
          </Popconfirm>
        </div>
      ),
    },
  ];

  const menuList = [
    {
      link: "#medical_history",
      name: "Medical History",
    },
    {
      link: "#medical_record",
      name: "Medical Records",
    },
    {
      link: "#vitals",
      name: "Vitals & Notes",
    },
    {
      link: "#prescribe_med",
      name: "Prescribe Medicines",
    },
    {
      link: "#prescribe_lab",
      name: "Prescribe Labs",
    },
  ];

  const cutFromMiddle = (longText) => {
    const maxLength = 20;
    let shortText = longText;

    if (longText?.length > maxLength) {
      const middle = Math.floor(longText.length / 2);
      const beginning = longText.slice(0, middle - 5);
      const end = longText.slice(middle + 30);
      shortText = `${beginning}...${end}`;
    }
    return shortText;
  };

  let medical_record_table = [];
  medicalRec?.map((med, index) => {
    let imgs = [];
    med?.instant_medical_record_files.length && med?.instant_medical_record_files?.map((f) => {
      imgs.push(f?.file);
    });
    med?.instant_medical_record_files.length && medical_record_table.push({
      key: index + 1,
      // key: med?.instant_medical_record_files
      med_rec_date: moment(med?.date).format('DD/MM/YYYY'),
      med_rec_reports: med?.total_reports,
      buttons: med?.instant_medical_record_files,
    });
  });
  // console.log(medicalRec,'imgs')

  const previous_record_table = [];

  let vitalTableLocale = {
    emptyText: "No vitals measured",
  };

  let vitalData = [];
  vitalTable?.health_scans?.map((scan, index) => {
    if (index === 0) {
      vitalData.push({
        key: index + 1,
        date: `${scan?.date} ${scan?.dateTime}`,
        heart_rate: scan?.heart_rate && `${scan?.heart_rate} BPM`,
        respiratory_rate:
          scan?.respiratory_rate && `${scan?.respiratory_rate} BPM`,
        blood_pressure: scan?.blood_pressure && `${scan?.blood_pressure} mmHG`,
        stress_level: scan?.stress_level,
        sdnn: scan?.sdnn && `${scan?.sdnn} MS`,
        spo2: scan.spo2 && `${scan?.spo2} %`,
        dateValue: scan?.date,
        timeValue: scan?.dateTime,
        heart_rate_value: scan?.heart_rate_value,
        respiratory_rate_value: scan?.respiratory_rate_value,
        stress_level_value: scan?.stress_level_value,
        spo2_value: scan?.spo2_value,
        sdnn_value: scan?.sdnn_value,
        blood_pressure_value: scan?.blood_pressure_value,
        sehat_score: scan?.sehat_score,
      });
    }
  });

  // console.log({ vitalData });

  let previousConsultationData = [];

  patient.previous_consultation.length > 0 &&
    patient.previous_consultation.forEach((item) => {
      previousConsultationData.push({
        date: item?.date,
        prescription: `Prescription-${item?.id}`,
        url: `/appointment/download-prescription/${item?.id}?is_html=1&is_download=1`,
        downloadUrl: `${process.env.REACT_APP_BASE_URL}/appointment/download-prescription/${item?.id}?is_html=1&is_download=1`
      });
    });

  // console.log({ previousConsultationData });

  const setDiseaseFunc = (type, value) => {
    if (type === "add") {
      arr.add(value);
      setCond([...arr]);
    } else {
      const index = arr.has(value);
      if (index === true) {
        arr.delete(value);
      }
      setCond([...arr]);
    }
  };

  const handleOnChange = (value, event) => {
    if (arr.has(value) === false) {
      setDiseaseFunc("add", value);
      setMed([
        ...med,
        <MedCancelCard
          text={value}
          id={med.length}
          cancel={true}
          setDiseaseFunc={setDiseaseFunc}
        />,
      ]);
    }
  };

  let completeApp = (values) => {
    // console.log(values, "valuesss");
    setFormValues(values);
    setModal2Visible(true);
    // setCanUserLeave(false);
    setBlockUserExit(false);
  };

  const completeAppointment = async () => {
    setBlockUserExit(false);
    setCompleteAppointmentLoader(true);
    let appointmentsInQueue = [];

    console.log({ startNextConsultation })

    const response = await API.get("/doctor/pending-appointment");

    if (response?.data?.code === 200) {
      appointmentsInQueue = response?.data?.data;
    }

    if (appointmentsInQueue?.length > 1) {
      appointmentsInQueue?.sort((a, b) => a?.id - b?.id);
    }

    let prescription_here = JSON.stringify(writePrescriptionInfo);

    // setBlockUserExit(true);
    setModal2Visible(false);
    setModal3Visible(false);
    let values = formValues;

    values.prescription_here = prescription_here;
    values.condition = cond;

    delete values.prevRecord;
    values?.medicine?.map((item) => {
      delete item.medicine;
      delete item.medName;
      delete item.key;
    });
    delete values.medicalRecord;

    delete values.vitalTable;

    let labData = prescribeData.slice(0);
    let lab_info = [];
    labData?.map((labs) => {
      lab_info.push({
        prescription_element_id: labs.prescription_element_id,
        description: labs?.description,
      });
    });
    values.lab = lab_info;

    values.medicine = medTable;

    // values.patient = patient
    let payload = {
      id: id,
      data: values,
    };

    const stopAgoraApi = stopApi(resourceId, stopId);
    const stopApiPayload = {
      cname: channelName,
      uid: params?.id?.toString(),
      clientRequest: {},
    };

    const customerKey = process.env.REACT_APP_AGORA_CUSTOMER_KEY;
    const customerSecret = process.env.REACT_APP_AGORA_CUSTOMER_SECRET;

    if (isProduction()) {
      try {
        const response = await axios.post(stopAgoraApi, stopApiPayload, {
          auth: {
            username: customerKey,
            password: customerSecret,
          },
        });
      } catch (error) { }
    }


    await dispatch(postConsult(payload)).then((data) => {
      if (data.payload.code === 200) {
        setStartCall(false);

        // leaveChannel()
        toast.success("Appointment is completed.");
        // setBlockUserExit(false);

        const appID = process.env.REACT_APP_AGORA_TEST_APP_ID;
        const appointmentId = params?.id;

        const channelName = `${appointmentId}`;
        let token;

        (async () => {
          try {
            const response = await API.get(`/generate-agora-rtm-token`);
            if (response?.data?.code === 200) {
              token = response?.data?.data?.token;

              if (appID && channelName) {
                const client = AgoraRTM.createInstance(appID);
                setBlockUserExit(false);

                await client.login({ token, uid: `${doctorId}` });

                let channel = client.createChannel(channelName);

                await channel.join();

                await channel
                  .sendMessage({ text: "appointment-ended" })
                  .then(() => {
                    setCompleteAppointmentLoader(false);
                    // console.log({ startNextConsultation });
                    // console.log({ appointmentsInQueue });
                    // console.log("message_sent");
                    if (startNextConsultation) {
                      if (appointmentsInQueue?.length > 1) {
                        history.push({
                          pathname: `/appointment/${appointmentsInQueue?.[1]?.id}`,
                          state: {
                            id: appointmentsInQueue?.[1]?.id,
                            type: appointmentsInQueue?.[1]?.type,
                            user_id: appointmentsInQueue?.[1]?.user_id,
                            visit_count: 0,
                          },
                        });
                      } else {
                        window.location.href = "/";
                      }
                    } else {
                      window.location.href = "/";
                    }
                  })
                  .catch((err) => {
                    setBlockUserExit(false);
                    setCompleteAppointmentLoader(false);
                    window.location.href = "/";
                  });
              }
            } else {
              setCompleteAppointmentLoader(false);
              window.location.href = "/";
            }
          } catch (error) {
            if (startNextConsultation) {
              if (appointmentsInQueue?.length > 1) {
                history.push({
                  pathname: `/appointment/${appointmentsInQueue?.[1]?.id}`,
                  state: {
                    id: appointmentsInQueue?.[1]?.id,
                    type: appointmentsInQueue?.[1]?.type,
                    user_id: appointmentsInQueue?.[1]?.user_id,
                    visit_count: 0,
                  },
                });
              } else {
                window.location.href = "/";
              }
            } else {
              window.location.href = "/";
            }
          }

        })();
        if (startNextConsultation) {
          if (appointmentsInQueue?.length > 1) {
            console.log("last");
            history.push({
              pathname: `/appointment/${appointmentsInQueue?.[1]?.id}`,
              state: {
                id: appointmentsInQueue?.[1]?.id,
                type: appointmentsInQueue?.[1]?.type,
                user_id: appointmentsInQueue?.[1]?.user_id,
                visit_count: 0,
              },
            });
          } else {
            window.location.href = "/";
          }
        } else {
          window.location.href = "/";
        }

        // setBlockUserExit(false);
        // setCompleteAppointmentLoader(false);
        // window.location.href = "/";
      } else {
        setCompleteAppointmentLoader(false);
        toast.error(data.payload.message);
      }
    });
  };

  const addMed = (values, values2) => {
    values.key = medData.length + 1;
    values2.key = medData.length + 1;
    let found = [];
    medicine?.data?.map((item) => {
      if (item.id === values.medicine) {
        found.push(item.name);
        found.push(item.id);
      }
    });
    values.medName = found[0];
    values2.medName = found[0];
    values.prescription_element_id = found[1];
    values2.prescription_element_id = found[1];

    let temp = [...new Set([...medData, values])];
    setMedData(temp);

    let temp2 = [...new Set([...medTable, values2])];
    setMedTable(temp2);
  };

  const addLab = (values) => {
    values.key = prescribeData.length + 1;
    let found = [];
    labs?.data?.map((item) => {
      if (item.id === values.lab_test) {
        found.push(item.name);
        found.push(item.id);

        item?.category?.map((elem) => {
          if (elem?.id === values?.description) {
            found.push(elem?.name);
          }
        });
      }
    });
    if (found.length) {
      values.lab_name = found[0];
      values.prescription_element_id = found[1];
      values.description = found?.[2];

      console.log(values, "labValue");

      let temp = [...new Set([...prescribeData, values])];
      setPrescribeData(temp);
    }
  };

  let medData2 = [];
  medTable?.map((item) => {
    item.medicine = item?.medName;
    medData2.push(item);
  });

  let prescribeData2 = [];
  prescribeData?.map((item) => {
    prescribeData2.push({ key: item.key, lab_test: item.lab_name });
  });

  appForm.setFieldsValue({
    vitalTable: vitalData,
    medicine: medData,
    lab: prescribeData,
  });

  useEffect(() => {
    if (config !== null && count <= 1) {
      setCount(count + 1);
      setStartCall(true);
    }
  }, [config]);

  const renderer = ({ minutes, seconds, completed }) => {
    if (minutes < 10) {
      minutes = "0" + minutes;
    }
    if (seconds < 10) {
      seconds = "0" + seconds;
    }

    if (completed) {
      if (!endAnnounced) {
        setModal3Visible(true);

        setTimeout(() => {
          // completeAppointment();
          setAppointmentCompleted(true);
        }, 5000);

        setendAnnounced(true);
      }
      return <h3 className="fs-20">Time Ended</h3>;
    } else {
      return (
        <h3 className="rem-time">
          {minutes}:{seconds}
        </h3>
      );
    }
  };

  useEffect(() => {
    let interval = setInterval(() => {
      let remainingTime = document.querySelector(".rem-time");

      if (remainingTime?.innerHTML == "02:00") {
        // Stringified time remaining
        setModal4Visible(true);
      }
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    API.get(`/doctor/pending-appointment`)
      .then((res) => {
        if (res?.data?.code === 200) {
          setPendingAppointments(res?.data?.data);
        }
      })
      .catch((err) => { });
  }, []);

  const [scroll, setScroll] = useState(false);
  useEffect(() => {
    window.addEventListener("scroll", () => {
      setScroll(window.scrollY > 650);
    });
  }, []);

  async function onCheckboxChange(e) {
    // setIsOnline(e);

    if (e === true) {
      const data = {
        is_instant_consultation: 1,
      };

      const response = await API.post(`/doctor/instant-online-offline`, data);

      if (response?.data?.code === 200) {
        setIsOnline(true);
      } else {
        setIsOnline(false);
      }
    } else {
      let instant = pendingAppointments;

      // console.log(selectDashboardDetails?.data?.appointment_listing, 'listing')

      if (instant?.length > 0) {
        setModal1Visible(true);
        setIsOnline(isOnline);
      }

      const data = {
        is_instant_consultation: 0,
      };

      const response = await API.post(`/doctor/instant-online-offline`, data);

      if (response?.data?.code === 200) {
        setIsOnline(false);
      } else {
        setIsOnline(true);
      }
    }
  }

  useEffect(() => {
    if (medTable.length > 0) {
      setTabSwitchState(1);
    }

    if (writePrescriptionInfo.length > 0) {
      setTabSwitchState(2);
    }

    if (writePrescriptionInfo.length === 0 && medTable.length === 0) {
      setTabSwitchState(0);
    }
  }, [medTable.length, writePrescriptionInfo.length]);

  useEffect(() => {
    if (appointmentCompleted) {
      completeAppointment();
    }
  }, [appointmentCompleted]);

  useEffect(() => {
    if (shouldDispatchMedicine) {
      dispatch(getMedicine());
      setShouldDispatchMedicine(false);
    }
  }, [shouldDispatchMedicine]);

  const forStartNextConsultation = (e) => {
    setStartNextConsultation(e.target.checked);
  };

  const forStartNextConsultation2 = (e) => {
    // console.log(`checked = ${e.target.checked}`);
    setStartNextConsultation(e.target.checked);
  };

  // previous consultation
  const columnsprev = [
    {
      title: (
        <div className="consultation_detail">
          <th>Doctor Name</th>
          <th>Reason for visit</th>
          <th>Date</th>
        </div>
      ),
      dataIndex: "drname",
      key: "drname",
    },

    {
      title: "Prescription",
      dataIndex: "prescription",
      key: "prescription",
      render: (text, record) => (
        <ul className="prescription_list">
          <li className="list_header">
            <ul>
              <li>Drug Name</li>
              <li>Medicine/Day</li>
              <li></li>
              <li></li>
              <li></li>
              <li> Duration</li>
              <li>Instructions</li>
            </ul>
          </li>
          <li className="list_pres">
            <ul>
              <li>Tylenol Syrup (100mg)</li>
              <li>
                <p>2 Teaspoon</p>
                <h6>Morning</h6>
              </li>
              <li>
                <p>2 Teaspoon</p>
                <h6>Afternoon</h6>
              </li>
              <li>
                <p>2 Teaspoon</p>
                <h6>Evening</h6>
              </li>
              <li>
                <p>2 Teaspoon</p>
                <h6>Night</h6>
              </li>
              <li>5 days</li>
              <li>Before meal</li>
            </ul>
          </li>
        </ul>
      ),
    },
    {
      title: "Details",
      dataIndex: "details",
      key: "details",
    },
  ];

  const dataprev = [
    {
      drname: (
        <div className="consultation_detai_listing">
          <p className="dr_name">Dr. Ismail Siddiqui</p>
          <p className="reason_name">Migraine issue</p>
          <p className="reason_name">10/4/2023</p>
        </div>
      ),

      details: (
        <Button className="view_more" onClick={() => setModal2Open(true)}>
          {" "}
          <img src={fileIcon} /> View More
        </Button>
      ),
    },
    {
      drname: (
        <div className="consultation_detai_listing">
          <p className="dr_name">Dr. Ismail Siddiqui</p>
          <p className="reason_name">Migraine issue</p>
          <p className="reason_name">10/4/2023</p>
        </div>
      ),
    },
    {
      drname: (
        <div className="consultation_detai_listing">
          <p className="dr_name">Dr. Ismail Siddiqui</p>
          <p className="reason_name">Migraine issue</p>
          <p className="reason_name">10/4/2023</p>
        </div>
      ),
    },
  ];

  const handleModalData = async (item) => {
    setModal2Open(true);
    setDownloadPastUrl(`${process.env.REACT_APP_BASE_URL}/appointment/download-prescription/${item?.get_prescription?.appointment_id}?is_html=1&is_download=1`)
    try {
      const response = await API.get(
        `/appointment/download-prescription/${item?.get_prescription?.appointment_id}?is_html=0`
      );
      if (response.data?.code === 200) {
        setModal2OpenData(response?.data?.data);
      }
    } catch (e) {
      console.log(e, "e");
    }
  };

  async function downloadCSVHandler() {
    downloadPrescription(id).then((res) => {
      // window.open(res?.data?.pdf_download_link, "_blank");
    });
  }

  const [visibleItems, setVisibleItems] = useState(1);

  const handleViewMore = () => {
    setVisibleItems((prevVisibleItems) => prevVisibleItems + 1);
  };

  const viewAllPrevConsultation = () => {
    setShowAll(true);
  };

  const handleFileView = (file) => {
    setViewSingleReportFile(file?.file);
    setViewSingleReport(true);
  };

  const hanldeConsultationView = (item) => {
    setShowPrevConsultationModal(item);
    setViewSinglePresc(true);
  };

  async function cancelAppointment(e) {
    setBlockUserExit(false);

    try {
      setCancelAppointmentLoader(true);

      const response = await API.get(`/appointment/cancel/${id}`);
      setCancelAppointmentLoader(false);

      if (response?.data?.code === 200) {
        window.location.href = "/";
      }
    } catch (error) {
      setCancelAppointmentLoader(false);
    }
  }

  function handleDiseaseSearch(value) {
    const filteredOptions = conditions.data?.disease?.filter((item) => {
      return item?.name?.toLowerCase()?.startsWith(value?.toLowerCase());
    });

    if (filteredOptions.length === 0) {
      setShowAddDiseaseBtn(true);
    } else {
      setShowAddDiseaseBtn(false);
    }
  }

  async function addCustomDisease(e) {
    if (showAddDiseaseBtn) {
      const data = {
        name: e.target.value,
      };
      try {
        setAddDiseaseLoader(true);
        const response = await API.post("/disease", data);
        if (response?.data?.code === 200) {
          setAddDiseaseLoader(false);
          diseaseRef.current?.blur();
          handleOnChange(e.target.value);
          setShouldDispatchDiseases(true);
          setShowAddDiseaseBtn(false);
        } else {
          setAddDiseaseLoader(false);
        }
      } catch (error) {
        setAddDiseaseLoader(false);
      }
    }
  }

  console.log({ prescribeData });




  return (
    <div className="appointment_first cover_space">
      {(completeAppointmentLoader ||
        cancelAppointmentLoader ||
        addDiseaseLoader ||
        addMedicineLoader ||
        medicineLoading ||
        labLoading ||
        addLabLoader) && <Loader />}
      {/* <Prompt when={setBlockUserExit}
              message={(location, action)=> {
                console.log(action, 'action');
                return "The following action will end the appointment. Are you sure you want to end the call?"
              }}></Prompt> */}
      {/* <NavigationPrompt when={setBlockUserExit}>
      {({ onConfirm, onCancel }) => (
    <ConfirmNavigationModal
      when={true}
      onCancel={onCancel}
      onConfirm={onConfirm}
    />
  )}
      </NavigationPrompt> */}
      <RouterPrompt
        when={blockUserExit}
        title="Mark as Complete?"
        cancelText=""
        okText="Ok"
        okFunction={completeAppointment}
        onOK={() => {
          return false;
        }}
        onCancel={() => false}
      />
      {loader && (
        <Form form={appForm} layout="vertical" onFinish={completeApp}>
          <Container fluid className="mt-5">
            {patient?.type !== "in-person" ? (
              <Row>
                {!viewSingleReport || viewSinglePresc ? (
                  <>
                    <Col md={4} className="d-block d-sm-none">
                      <div className="mt-6 box_mobile_call">
                        <Row>
                          <Col xs={7}>
                            <div className="pat_info_mob">
                              <HeadingDescVsmall text={patient?.name} />
                              <HeadingDescVsmall
                                text={
                                  patient?.age === null || patient?.age === ""
                                    ? "-"
                                    : patient?.age + " years"
                                }
                              />

                              <HeadingDescVsmall
                                text={
                                  patient?.gender === null
                                    ? "-"
                                    : patient?.gender
                                }
                              />
                            </div>
                            <div
                              className="instant_consult mb-2"
                              style={{ display: "flex" }}
                            >
                              <HeadingDescSmall text="DoctorNow" />
                              <Switch
                                className="ms-2 is-online-switch"
                                checked={isOnline}
                                onChange={onCheckboxChange}
                              />
                            </div>
                          </Col>
                          <Col xs={5}>
                            <div className=" ">
                              <div className="  heading-captalize mobile_time01">
                                <Countdown date={timeRem} renderer={renderer} />
                                <HeadingWithSpaceLarge text="  Remaining" />
                              </div>
                              <div className="heading-captalize  mobile_time01 pt-mob">
                                <HeadingWithSpaceLarge text="Patient In Queue" />
                                <h3>01</h3>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Col>
                  </>
                ) : null}

                <Col
                  md={8}
                  id="mobile_vid"
                  className={scroll ? "fixedSameVideoTop" : ""}
                >
                  {startCall && (
                    <div
                      className={`video_div position-relative ${isMobile && "noPadding"
                        } ${(viewSingleReport === true && "currentViewState") ||
                        (viewSinglePresc === true && "currentViewState")
                        }`}
                    >
                      {/* <img src={patient_img} alt="patient_img" className="img_vid" /> */}
                      <Agoraa
                        doctorName={AppointmentData?.data?.doctor?.name}
                        setShowCancelModal={setShowCancelModal}
                      />
                      {/* doctor Name for small frame */}
                      <p className="topNameDoctorNow">
                        {AppointmentData?.data?.doctor?.name}
                      </p>
                      {/* doctor Name for small frame */}
                      <div className="fixedScreenHeading withoutScrollFixed">
                        <HeadingDescVsmall text={patient?.name} />
                        <div className="onlyForFixedRemainingTime">
                          <Countdown date={timeRem} renderer={renderer} />
                        </div>
                      </div>
                    </div>
                  )}
                </Col>
                <Col md={4}>
                  <div
                    className={
                      mobile
                        ? "d-none"
                        : "white_color_div patient-info-set hk_white_video_right_area"
                    }
                  >



                    <div className="column_flex nameP ">
                      <HeadingDescVsmall text={patient?.name} />
                    </div>

                    <div className="column_flex">
                      <HeadingDescVsmall text="Age" />
                      <HeadingDescVsmall
                        text={
                          patient?.age === null || patient?.age === ""
                            ? "-"
                            : patient?.age + " years"
                        }
                      />
                    </div>
                    <div
                      className="column_flex"
                      style={{ textTransform: "capitalize" }}
                    >
                      <HeadingDescVsmall text="Gender" />
                      <HeadingDescVsmall
                        text={patient?.gender === null ? "-" : patient?.gender}
                      />
                    </div>

                    <div
                      className="column_flex"
                      style={{ textTransform: "capitalize" }}
                    >
                      <HeadingDescVsmall text="Date Of Birth" />
                      <HeadingDescVsmall
                        text="18/02/1992"
                      />
                    </div>



                    <div
                      className="column_flex"
                      style={{ textTransform: "capitalize" }}
                    >
                      <HeadingDescVsmall text="CNIC" />
                      <HeadingDescVsmall
                        text="109809280983"
                      />
                    </div>



                    <div
                      className="column_flex"
                      style={{ textTransform: "capitalize" }}
                    >
                      <HeadingDescVsmall text="Address" />
                      <HeadingDescVsmall
                        text="10C- Sunset lane 5..."
                      />
                    </div>


                    <div
                      className="column_flex"
                      style={{ textTransform: "capitalize" }}
                    >
                      <HeadingDescVsmall text="Ethnicity" />
                      <HeadingDescVsmall
                        text="Asian"
                      />
                    </div>

                    <div className="patient_status follow_up">
                      <HeadingDescVsmall text="New Patient" />
                    </div>



                    <hr className="break-lines d-none d-lg-block mt-0 mb-0" />
                    <div className="flex_center">
                      <div className="column_flex heading-captalize">
                        <HeadingWithSpaceLarge text="Time " />
                        <Countdown date={timeRem} renderer={renderer} />
                      </div>
                      <div className="column_flex heading-captalize">
                        <HeadingWithSpaceLarge text="Patient Queue" />
                        <h3>{patientQueueCount?.patient_count}</h3>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            ) : (
              <Row>
                <Col md={24}>
                  <div className="past_consultation">
                    <div className={mobile ? "d-none" : "white_color_div"}>
                      <HeadingWithSpaceLarge text="PATIENT INFORMATION" />
                      <div className="flex_center">
                        <div className="column_flex">
                          <HeadingDescVsmall text="Patient Name" />
                          <HeadingDescVsmall text={patient?.name} />
                        </div>
                        <div className="column_flex">
                          <HeadingDescVsmall text="Age" />
                          <HeadingDescVsmall
                            text={
                              patient?.age === null || patient?.age === ""
                                ? "-"
                                : patient?.age + " years"
                            }
                          />
                        </div>
                        <div className="column_flex">
                          <HeadingDescVsmall text="Gender" />
                          <HeadingDescVsmall
                            text={
                              patient?.gender === null ? "-" : patient?.gender
                            }
                          />
                        </div>
                        <div
                          className="column_flex"
                          style={{ textTransform: "capitalize" }}
                        >
                          <HeadingDescVsmall text="City" />
                          <HeadingDescVsmall
                            text={
                              !userCity || typeof userCity === "undefined"
                                ? "-"
                                : userCity
                            }
                          />
                        </div>
                        {patient?.reason && (
                          <div className="column_flex">
                            <HeadingDescVsmall text="Reason for Visiting" />
                            <HeadingDescVsmall text={patient?.reason} />
                          </div>
                        )}
                        {parseInt(visit_count) > 0 ? (
                          <div className="patient_status follow_up">
                            <HeadingDescVsmall text="Follow Up Appointment" />
                          </div>
                        ) : (
                          <div className="patient_status first_time">
                            <HeadingDescVsmall text="First Time Appointment" />
                          </div>
                        )}
                        <div className="column_flex">
                          <HeadingDescVsmall text="Appointment Remaining Time" />
                          <Countdown
                            className="time-rem"
                            date={timeRem}
                            renderer={renderer}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            )}
          </Container>

          <>
            <Box sx={{ width: "100%", typography: "body1" }}>
              <TabContext value={tabValue1}>
                <div
                  className={
                    scroll
                      ? "container-fluid mt-5 whenNotFixedVideo"
                      : "container-fluid mt-5 whenNotFixedVideo"
                  }
                >
                  <div className="row">
                    <div className="col-12 col-lg-12 ">
                      <div className="row align-items-end">
                        <div className="col-12 col-lg-10">
                          <Box >
                            <TabList
                              onChange={handleChangeTabs}
                              aria-label="lab API tabs example"
                              className="tabListingBIDE"
                            >
                              <Tab
                                className="tab-1 tabItem"
                                label="Prescription"
                                value="11"
                              />
                              <Tab
                                className="tab-2 tabItem"
                                label="Personal History"
                                value="21"
                              />
                              <Tab
                                className="tab-3 tabItem"
                                label="Medical History"
                                value="31"
                              />
                              <Tab
                                className="tab-4 tabItem"
                                label="Diabetes History"
                                value="41"
                              />
                              <Tab
                                className="tab-4 tabItem"
                                label="Lab Reports"
                                value="51"
                              />
                              <Tab
                                className="tab-4 tabItem"
                                label="Vitals"
                                value="61"
                              />
                            </TabList>
                          </Box>

                        </div>
                        <div className="col-12 col-lg-2 ms-auto">
                          <label className="d-block mb-1 followUp"> Followup Date</label>
                          <div className="datepickerBox dd">
                            <img src={calendar01} className="img-fluid imgCL"></img>
                            <DatePicker className="datepickerDate" />
                          </div>

                        </div>
                      </div>
                      <hr></hr>
                    </div>
                  </div>
                  {/* end tabs section */}

                </div>



                <Container fluid>
                  <Col md={12}>
                    <Row>
                      <Col md={12}>
                        <TabPanel value="11" className="pt-3 px-0">
                          <div className="newTabBoxes prescription-parent ">
                            <Box sx={{ width: "100%", typography: "body1" }}>
                              <TabContext value={tabValue}>
                                <Box
                                  sx={{ borderBottom: 1, borderColor: "divider" }}
                                >
                                  <TabList
                                    onChange={handleTabs}
                                    aria-label="lab API tabs example"
                                  >
                                    <Tab
                                      className="tab-10"
                                      label="Medicine"
                                      value="1"
                                    />
                                    <Tab
                                      className="tab-2"
                                      label="INSULIN"
                                      value="266"
                                    />
                                    <Tab
                                      className="tab-3"
                                      label="LAB TESTS"
                                      value="3"
                                    />
                                    <Tab
                                      className="tab-4"
                                      label="REMARKS"
                                      value="4"
                                    />
                                  </TabList>
                                </Box>
                                <TabPanel value="1" className="tabContent appointment_div_data mainTabletBox px-0 prescription1" id="prescription">
                                  <div className="white_color_div mb-4">
                                    <div className="gap_div">
                                      <Form.Item>
                                        <MedForm
                                          medicine={medicine}
                                          complete={addMed}
                                          medTable={medTable}
                                          setMedTable={setMedTable}
                                          setEditMedicineStatus={
                                            setEditMedicineStatus
                                          }
                                          editMedicineStatus={editMedicineStatus}
                                          setEditMedicine={setEditMedicine}
                                          editMedicine={editMedicine}
                                          setShouldDispatchMedicine={
                                            setShouldDispatchMedicine
                                          }
                                          setAddMedicineLoader={
                                            setAddMedicineLoader
                                          }
                                        />
                                        {/* <MedForm
                                      medicine={medicine}
                                      complete={addMed}
                                      medTable={medTable}
                                      setMedTable={setMedTable}
                                      setShouldDispatchMedicine={
                                        setShouldDispatchMedicine
                                      }
                                    /> */}
                                      </Form.Item>
                                    </div>
                                  </div>
                                  <div>

                                    {medTable?.length > 0 && (<> <h2 className="headingtop">Active Medicines</h2></>)}

                                    <Table
                                      style={{ backgroundColor: "#fff" }}
                                      className="table instant-feedback-table ss"
                                    >
                                      <>
                                        <thead>
                                          <tr className="first-table-row">
                                            <th
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-left"
                                            >
                                              Medicine
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Generic
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Type
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Route
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Item Strength
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Duration
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Frequency
                                            </th>

                                            <th
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Instructions
                                            </th>
                                            <th className=""></th>
                                          </tr>

                                          {medTable?.length > 0 && (

                                            <tr className="second-table-row dd ss">
                                              <th className="text-left">&nbsp;</th>
                                              <th className="text-left">&nbsp;</th>
                                              <th className="text-left">&nbsp;</th>
                                              <th className="text-left">&nbsp;</th>
                                              <th className="text-center">
                                                &nbsp;
                                              </th>
                                              <th className="text-center">
                                                &nbsp;
                                              </th>
                                              <th>
                                                <table className="w-100">
                                                  <tr>
                                                    <th
                                                      className="text-center"
                                                      style={{ color: "#078A8E" }}
                                                    >
                                                      M
                                                    </th>
                                                    <th
                                                      className="text-center"
                                                      style={{ color: "#078A8E" }}
                                                    >
                                                      A
                                                    </th>
                                                    <th
                                                      className="text-center"
                                                      style={{ color: "#078A8E" }}
                                                    >
                                                      E
                                                    </th>
                                                    <th
                                                      className="text-center"
                                                      style={{ color: "#078A8E" }}
                                                    >
                                                      N
                                                    </th>
                                                  </tr>
                                                </table>
                                              </th>
                                              <th className="text-center">
                                                &nbsp;
                                              </th>

                                            </tr>
                                          )}
                                        </thead>
                                        <tbody>
                                          {medTable?.length > 0 ? (
                                            medTable.map((item, index) => (
                                              <tr key={index} className="align-middle">
                                                <td className="text-left">
                                                  {" "}
                                                  {item?.medicine}{" "}
                                                </td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td className="text-center">
                                                  {item?.number_of_days}
                                                </td>
                                                <td>

                                                  <table className="w-100">
                                                    <tbody>
                                                      <tr className="second_td_row">
                                                        <td className="text-center">
                                                          {item?.afternoon && (
                                                            <span className="bg-change-td">
                                                              {item?.afternoon}{" "}
                                                              {/* {item?.afternoon &&
                                                        item?.unit} */}
                                                            </span>
                                                          )}
                                                        </td>
                                                        <td className="me-2 text-center">
                                                          {item?.morning && (
                                                            <span className="bg-change-td">
                                                              {item?.morning}{" "}
                                                              {/* {item?.morning && item?.unit}{" "} */}
                                                            </span>
                                                          )}
                                                        </td>
                                                        <td className="text-center">
                                                          {item?.evening && (
                                                            <span className="bg-change-td">
                                                              {item?.evening}{" "}
                                                              {/* {item?.evening && item?.unit}{" "} */}
                                                            </span>
                                                          )}
                                                        </td>
                                                        <td className="text-center">
                                                          {item?.night && (
                                                            <span className="bg-change-td">
                                                              {item?.night}{" "}
                                                              {/* {item?.night && item?.unit}{" "} */}
                                                            </span>
                                                          )}
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>

                                                </td>


                                                {/* <td ><img  src={greenIcon} alt='' className='img-fluid ms-4' /></td> */}
                                                <td className="text-center">
                                                  {" "}
                                                  {item?.is_after_meal == "1"
                                                    ? "After Meal"
                                                    : "Before Meal"}{" "}
                                                </td>
                                                <td className="text-center">
                                                  <img
                                                    style={{ cursor: "pointer" }}
                                                    src={RemovePre}
                                                    alt=""
                                                    onClick={(e) => {
                                                      let modified =
                                                        medTable?.filter(
                                                          (med, idx) => {
                                                            return (
                                                              med?.medicine !=
                                                              item?.medicine
                                                            );
                                                          }
                                                        );
                                                      setMedTable(modified);
                                                    }}
                                                  />
                                                  <img
                                                    style={{ cursor: "pointer" }}
                                                    src={EditPre}
                                                    alt=""
                                                    disabled={editMedicineStatus}
                                                    className={`img-fluid ms-2 ${editMedicineStatus &&
                                                      "disabled_edit"
                                                      }`}
                                                    onClick={(e) => {
                                                      let modified =
                                                        medTable?.filter(
                                                          (med, idx) => {
                                                            return (
                                                              med?.medicine !=
                                                              item?.medicine
                                                            );
                                                          }
                                                        );
                                                      setMedTable(modified);
                                                      setEditMedicine(item);
                                                      setEditMedicineStatus(true);
                                                      // setEditMedicine(modified);
                                                    }}
                                                  />

                                                  <img

                                                    src={notallow}
                                                    alt=""
                                                    className="img-fluid ms-2 false "


                                                  />
                                                </td>
                                              </tr>
                                            ))
                                          ) : (
                                            <tr className="no_med">
                                              <td colSpan="9" className="text-center">No medicine records</td>
                                            </tr>
                                          )}

                                        </tbody>
                                      </>
                                    </Table>
                                  </div>
                                </TabPanel>
                                <TabPanel value="266" className="tabContent appointment_div_data mainTabletBox px-0 prescription1 prescription-parent ">
                                  <div className="white_color_div">
                                    <div className="gap_div">
                                      <Form.Item>
                                        <InsulinForm />
                                      </Form.Item>
                                    </div>
                                  </div>



                                  <div>
                                    <Table
                                      style={{ backgroundColor: "#fff" }}
                                      className="table instant-feedback-table ss"
                                    >
                                      <>
                                        <thead>
                                          <tr className="first-table-row">
                                            <th
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-left"
                                            >
                                              Insulin
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Unit
                                            </th>
                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Duration
                                            </th>

                                            <th
                                              colSpan={1}
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Frequency
                                            </th>

                                            <th
                                              style={{ color: "#313131" }}
                                              className="fw-400 text-center"
                                            >
                                              Instructions
                                            </th>
                                            <th className=""></th>
                                          </tr>



                                          <tr className="second-table-row dd">

                                            <th className="text-left">&nbsp;</th>
                                            <th className="text-center">
                                              &nbsp;
                                            </th>
                                            <th className="text-center">
                                              &nbsp;
                                            </th>
                                            <th>
                                              <table className="w-100">
                                                <tr>
                                                  <th
                                                    className="text-center"
                                                    style={{ color: "#078A8E" }}
                                                  >
                                                    Morning
                                                  </th>
                                                  <th
                                                    className="text-center"
                                                    style={{ color: "#078A8E" }}
                                                  >
                                                    Afternoon
                                                  </th>
                                                  <th
                                                    className="text-center"
                                                    style={{ color: "#078A8E" }}
                                                  >
                                                    Evening
                                                  </th>
                                                  <th
                                                    className="text-center"
                                                    style={{ color: "#078A8E" }}
                                                  >
                                                    Night
                                                  </th>
                                                </tr>
                                              </table>
                                            </th>
                                            <th className="text-center">
                                              &nbsp;
                                            </th>

                                          </tr>

                                        </thead>
                                        <tbody>


                                          <tr className="align-middle">
                                            <td className="text-left">
                                              {" "}
                                              {/* {item?.medicine}{" "} */}
                                              Humulin
                                            </td>
                                            <td>5000</td>

                                            <td className="text-center">
                                              3 Days
                                            </td>
                                            <td>

                                              <table className="w-100">
                                                <tbody>
                                                  <tr className="second_td_row">
                                                    <td className="text-center">

                                                      <span className="bg-change-td">
                                                        {/* {item?.afternoon}{" "} */}
                                                        {/* {item?.afternoon &&
                                                        item?.unit} */}
                                                        1
                                                      </span>

                                                    </td>
                                                    <td className="me-2 text-center">

                                                      <span className="bg-change-td">
                                                        {/* {item?.morning}{" "} */}
                                                        {/* {item?.morning && item?.unit}{" "} */}
                                                        1
                                                      </span>

                                                    </td>
                                                    <td className="text-center">

                                                      <span className="bg-change-td">
                                                        {/* {item?.evening}{" "} */}
                                                        {/* {item?.evening && item?.unit}{" "} */}
                                                        1
                                                      </span>

                                                    </td>
                                                    <td className="text-center">

                                                      <span className="bg-change-td">
                                                        {/* {item?.night}{" "} */}
                                                        {/* {item?.night && item?.unit}{" "} */}
                                                        1
                                                      </span>

                                                    </td>
                                                  </tr>
                                                </tbody>
                                              </table>

                                            </td>


                                            {/* <td ><img  src={greenIcon} alt='' className='img-fluid ms-4' /></td> */}
                                            <td className="text-center">
                                              {" "}
                                              {/* {item?.is_after_meal == "1"
                                            ? "After Meal"
                                            : "Before Meal"}{" "} */}
                                              After Meal
                                            </td>
                                            <td className="text-center">
                                              <img
                                                style={{ cursor: "pointer" }}
                                                src={delete1}
                                                alt=""

                                              />
                                              <img
                                                style={{ cursor: "pointer" }}
                                                src={EditPre}
                                                alt=""

                                                className={`img-fluid ms-2 ${editMedicineStatus &&
                                                  "disabled_edit"
                                                  }`}

                                              />
                                            </td>
                                          </tr>



                                        </tbody>
                                      </>
                                    </Table>
                                  </div>
                                </TabPanel>

                                <TabPanel value="3" className="tabContent prescription-parent px-0">
                                  <div
                                    className={
                                      mobile
                                        ? location?.search?.split("?")[1] === "#prescribe_lab"
                                          ? "tab_data cover_space3 white_color_div pb-0"
                                          : "d-none"
                                        : "tab_data cover_space3 white_color_div pb-0"
                                    }
                                    id="prescribe_lab"
                                  >
                                    <div className="appointment_div_data">
                                      <div className="white_color_div pb-0">

                                        <div className="gap_div pt-0">
                                          <Form.Item>
                                            <LabForm
                                              labs={labs}
                                              complete={addLab}
                                              prescribeData={prescribeData}
                                              setAddLabLoader={setAddLabLoader}
                                              setShouldDispatchLabs={setShouldDispatchLabs}
                                            />
                                          </Form.Item>
                                        </div>

                                      </div>
                                    </div>
                                  </div>
                                  <div className="appointment_div_data">
                                    <div className="white_color_div1">


                                      {prescribeData.length > 0 ? (
                                        <div className="prescriptionBox">
                                          <h4>Lab Test </h4>
                                        </div>
                                      ) : null}
                                      <Table className="table instant-feedback-table lab-test-table border_bottom_rem">
                                        <>
                                          <tbody>

                                            {prescribeData?.map((item, index) => {
                                              return (

                                                <tr>
                                                  <td className="med-test-type text-left w-25 br-0 pl-4">
                                                    {item?.lab_name}
                                                  </td>


                                                  <td className="w-5 text-end pe-4">
                                                    <img
                                                      style={{ cursor: "pointer" }}
                                                      src={delete1}
                                                      alt=""
                                                      className="img-fluid me-2"
                                                      onClick={(e) => {
                                                        let modified = prescribeData?.filter(
                                                          (med, idx) => {
                                                            return (

                                                              med?.description != item?.description
                                                            );
                                                          }
                                                        );
                                                        setPrescribeData(modified);
                                                      }}
                                                    />
                                                    <img
                                                      style={{ cursor: "pointer" }}
                                                      src={EditPre}
                                                      alt=""
                                                      className="img-fluid"

                                                    />
                                                  </td>
                                                </tr>
                                              );
                                            })}
                                          </tbody>
                                        </>
                                      </Table>
                                    </div>
                                  </div>
                                </TabPanel>
                                <TabPanel value="4" className="tabContent prescription-parent px-0">
                                  <div className="appointment_div_data historyBox">
                                    <div className="white_color_div pb-0 col-lg-12">
                                      <Row className="w-100">
                                        <Col md={12} >
                                          <HeadingWithSpaceLarge text="REMARKS" />
                                          <Form.Item name="cosultation_note" label="">
                                            {/* <p className="labelText">Notes</p> */}
                                            <TextArea
                                              placeholder="Write something here..."
                                              defaultValue={
                                                AppointmentData?.data?.prescription
                                                  ?.patient_consultation_note
                                              }
                                              onChange={(e) => {
                                                setNote({ note: e.target.value });
                                                // console.log("NOTE", note)
                                              }}
                                              rows={6}
                                              className="c_input inputBox"
                                            />
                                            <span className="limit">500 Limit </span>
                                          </Form.Item>
                                        </Col>
                                      </Row>
                                      <Row className="d-none">
                                        <Col lg={6}>
                                          <HeadingWithSpaceLarge text="REMARKS" />
                                          <Form.Item name="cosultation_note" label="" className="remarks">
                                            {/* <p className="labelText">Notes</p> */}
                                            <TextArea
                                              placeholder="Write something here..."
                                              defaultValue={
                                                AppointmentData?.data?.prescription
                                                  ?.patient_consultation_note
                                              }
                                              onChange={(e) => {
                                                setNote({ note: e.target.value });
                                                // console.log("NOTE", note)
                                              }}
                                              rows={6}
                                              className="c_input inputBox "
                                            />

                                          </Form.Item>
                                        </Col>
                                        <Col lg={6} className="right_remark">
                                          <HeadingWithSpaceLarge text="PAST REMARKS" />
                                          <div className="boxremarks">
                                            <p className="text-right">12/06/2023</p>
                                            <div className="remark">
                                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                            </div>
                                            <p className="text-right">12/06/2023</p>
                                            <div className="remark">
                                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                            </div>
                                            <p className="text-right">12/06/2023</p>
                                            <div className="remark">
                                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                            </div>
                                          </div>
                                        </Col>
                                      </Row>
                                    </div>
                                  </div>
                                </TabPanel>
                              </TabContext>
                            </Box>
                          </div>
                        </TabPanel>
                        <TabPanel value="21" className="boxTab tabOne">
                          <Row>
                            <Col md={12}>
                              <div className="boxnew">
                                <PersonalHistory />
                              </div>
                            </Col>
                          </Row>
                        </TabPanel>

                        <TabPanel value="31" className="boxTab tabtwo">
                          <Row>
                            <Col md={12}>
                              <div className="boxnew">
                                <MedicalHistory />
                              </div>
                            </Col>
                          </Row>
                        </TabPanel>

                        <TabPanel value="41" className="boxTab taThree">
                          <Row>
                            <Col md={12}>
                              <DiabetesHis />
                            </Col>
                          </Row>
                        </TabPanel>
                        <TabPanel value="51" className="boxTab taThree">
                          <Row>
                            <Col md={12}>
                              <div className="boxnew">
                                <LabsReport />
                              </div>
                            </Col>
                          </Row>
                        </TabPanel>
                        <TabPanel value="61" className="boxTab taThree">
                          <Row>
                            <Col md={12}>
                              <div className="boxnew">
                                <Vitals />
                              </div>
                            </Col>
                          </Row>
                        </TabPanel>
                      </Col>
                    </Row>
                  </Col>
                </Container>
              </TabContext>
            </Box>
          </>

          {/* New Tabs Start */}

          {/* New Tabs end */}













          <div className="bottom_btn bg-transparent">
            <a
              className="appoitment-cancel-btn fixed_app_button bg-transparent text-uppercase d-flex align-items-center justify-content-center color-313131"
              onClick={(e) => setShowCancelModal(true)}
            >
              Cancel
            </a>

            <button
              className="submit-btn-completed add-record-btn text-uppercase w-100"
              htmlType="submit"
            >
              <span className="hk_for_center"> MARK AS COMPLETE</span>
              <span className="add-record-chevron">
                <FiChevronRight />
              </span>
            </button>
          </div>


          {/* ----------------leave consultation modal ----------------------------- */}
          <Modal
            className="leaveConsultationModal"
            title=""
            centered
            visible={modal2Visible}
            onOk={() => completeAppointment()}
            onCancel={(e) => {
              setModal2Visible(false);
            }}
            okText="Yes"
            cancelText="No"
          >
            <div className="col-md-9 m-auto text-center">
              <h5 className="ff-Nunito color-313131 fs-24 line-height-35 fw-500">
                Are you sure you want mark this consultation as complete?
                <div className="hk_go_for_next">
                  <Checkbox onChange={forStartNextConsultation}>
                    Start next video call
                  </Checkbox>
                </div>
              </h5>
            </div>
          </Modal>
          {/* <AppointmentModal btn1Text={"yes"} btn2Text={"no"} show={modal2Visible}
          description="Are you sure you want to leave
          the consultation?" />
          {/* ------------------------mark complete popup -------------------------*/}

          <Modal
            className="consultaionEndedModal"
            title=""
            centered
            visible={modal3Visible}
            closable={false}
            // onOk={() => completeAppointment()}
            cancelButtonProps={{ style: { display: "none" } }}
            footer={[
              // <Button className="col-md-9 m-auto" key="info" onClick={() => completeAppointment()}>
              //   Mark Complete
              // </Button>

              <Button
                className="col-md-9 m-auto"
                key="info"
                onClick={() => setAppointmentCompleted(true)}
              >
                MARK AS COMPLETE
              </Button>,
            ]}
          >
            <div className="col-md-9 m-auto text-center">
              <h5
                style={{ fontSize: "28px" }}
                className="ff-Nunito color-313131 line-height-35 fw-500"
              >
                Consultation ended
              </h5>
              <p style={{ fontSize: "18px" }} className="pt-2 pb-2">
                Please mark this consultation as complete.
              </p>
              <div className="hk_go_for_next">
                <Checkbox onChange={forStartNextConsultation2}>
                  Start next video call
                </Checkbox>
              </div>
            </div>
          </Modal>
          {/* ----------------------for instant consulation disable------------------- */}
          <Modal
            className="consultaionEndedModal"
            title=""
            centered
            visible={modal1Visible}
            onOk={() => {
              setModal1Visible(false);
            }}
            cancelButtonProps={{ style: { display: "none" } }}
            footer={[
              <Button
                className="col-md-9 m-auto"
                key="info"
                onClick={() => {
                  setModal1Visible(false);
                }}
              >
                Okay
              </Button>,
            ]}
          >
            <div className="col-md-8 m-auto text-center">
              <img
                src={disableConsultation}
                alt=""
                className="img-fluid mb-3"
              />
              <h5 className="ff-Nunito color-313131 fs-24 line-height-35 fw-500 mb-3">
                Instant Consultation disabled
              </h5>
              <p className="ff-circular fw-300 fs-17 line-height-24 mb-3">
                Your instant consultation bookings will be temporarily disabled.{" "}
              </p>
              <p className="ff-circular fw-300 fs-17 line-height-24">
                Please attend to the next patient in queue.
              </p>
            </div>
          </Modal>
          {/* ----------------consultation about end modal ----------------------------- */}
          <Modal
            className="leaveConsultationModal consultationAboutEnd"
            title=""
            centered
            visible={modal4Visible}
            closable={false}
            onOk={(e) => {
              setModal4Visible(false);
            }}
            okText="OK"
            cancelButtonProps={{ style: { display: "none" } }}
          >
            <div className="col-md-11 m-auto text-center">
              <h5 className="ff-Nunito color-313131 fs-24 line-height-35 fw-500">
                The consultation is about to end
              </h5>
            </div>
          </Modal>

          {/* Cancel Consultation Modal */}

          <Modal
            className="leaveConsultationModal consultationAboutEnd"
            title=""
            centered
            visible={showCancelModal}
            onCancel={(e) => setShowCancelModal(false)}
            okText="Yes"
            cancelText="No"
            closable={true}
            onOk={cancelAppointment}
          >
            <div className="col-md-9 m-auto text-center">
              <h5 className="ff-Nunito color-313131 fs-24 line-height-35 fw-500 pb-3">
                Are you sure you want to leave this consultation?
              </h5>
            </div>
          </Modal>
          <ToastContainer />
        </Form>
      )}
    </div>
  );
}

export default AppointmentFirstTime;
