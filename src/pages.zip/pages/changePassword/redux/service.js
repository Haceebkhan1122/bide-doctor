import { post } from "../../../utils/httpService";

const SERVICE_URLS = {
  postPasswordUpdate: () => '/doctor/password/update',
};

export const postPasswordUpdate = ( data, params ) => {
  return post(SERVICE_URLS.postPasswordUpdate(), data, params);
};