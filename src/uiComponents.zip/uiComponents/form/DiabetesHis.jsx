import React, { useEffect, useMemo, useState, useRef } from "react";
import { Select, InputNumber, Form, Input, Button, Checkbox, Radio } from "antd";
import { Col, Row } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import "./personalhistory.css";
import "./diabeteshis.css";
import swal from "sweetalert";
import uniqBy from "lodash.uniqby";
import API from "../../utils/customAxios";
import arrowdropdown from "../../assets/images/svg/dropdown-icon.svg";
import { DatePicker, Space } from 'antd';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Textarea } from "evergreen-ui";
function DiabetesHis() {
    return (
        <>
            <Row className="diabetesHis mainLabelClass">
                <Col lg={6}>
                    <div className="boxnew p-26 newFormBox">
                        <Row className="mb-1">
                            <Col lg={4} className="spacing001 mb-3">
                                <div className="datepickerNew dd">
                                    <DatePicker className="datepickerDate" />
                                    <FontAwesomeIcon icon="fas fa-calendar-alt" className="iconClander" />
                                </div>
                            </Col>
                        </Row>
                        <Row className="mb-1">
                            <Col lg={12} className="spacing001  mb-3">
                                <p className="labelText1 fs-16 ps-0">Type of Diabetes</p>
                                <div className="borderBox2 radioBox newSpacing radioNew">

                                    <Radio.Group disabled defaultValue="pre">
                                        <Radio value="pre">Pre Diabetes</Radio>
                                        <Radio value="type1">Type i Diabetes</Radio>
                                        <Radio value="type2">Type iI Diabetes</Radio>
                                        <Radio value="gestational">Gestational Diabetes</Radio>
                                    </Radio.Group>

                                </div>
                            </Col>
                        </Row>
                        <Row className="mb-1">
                            <Col lg={4} className="spacing001 mb-3">
                                <p className="labelText1 fs-16 ps-0">Year Diagnosed</p>
                                <div className="datepickerNew dd">
                                    <DatePicker className="datepickerDate" />
                                    <FontAwesomeIcon icon="fas fa-calendar-alt" className="iconClander" />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg={12} className="spacing001">
                                <Row className="align-items-center">
                                    <Col lg={7}> <p className="labelText1 fs-16 ps-0">Is patient taking insulin?</p></Col>
                                    <Col lg={3} className="ms-auto">
                                        <div className="borderBox2 radioBox newSpacing">
                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>
                                        </div>
                                    </Col>
                                </Row>
                                <div className="position-relative mt-1">
                                    <Form.Item
                                        name="takinginsulin"
                                        rules={[{ required: false, }]}
                                    >

                                        <Textarea className="form-control textarea01  " placeholder="Specify insulin details" readOnly></Textarea>
                                        <span className="character">100 character limit</span>
                                    </Form.Item>
                                </div>
                            </Col>
                        </Row>

                        <Row>
                            <Col lg={12} className="spacing001">
                                <Row className="align-items-center">
                                    <Col lg={7}> <p className="labelText1 fs-16 ps-0">Is patient diagnosed with Ketoacidosis?</p></Col>
                                    <Col lg={3} className="ms-auto">
                                        <div className="borderBox2 radioBox newSpacing">
                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>
                                        </div>
                                    </Col>
                                </Row>
                                <div className="position-relative mt-1">
                                    <Form.Item
                                        name="Ketoacidosis"
                                        rules={[{ required: false, }]}
                                    >

                                        <Textarea className="form-control textarea01  " placeholder="Specify insulin details" readOnly></Textarea>
                                        <span className="character">100 character limit</span>
                                    </Form.Item>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg={12} className="spacing001">
                                <p className="labelText1 fs-16 ps-0">Remarks</p>
                                <div className="position-relative mt-1">
                                    <Form.Item
                                        name="remarks"
                                        rules={[{ required: false, }]}
                                    >

                                        <Textarea className="form-control textarea01  " placeholder="Specify insulin details" readOnly></Textarea>
                                        <span className="character">100 character limit</span>
                                    </Form.Item>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </Col>
                <Col lg={6}>
                    <div className="boxnew py-27">
                        <h3 className="heading1 px-40">SMBG</h3>
                        <div className='medicleHistory labReport position-relative h-100'>
                            <table
                                className="table medicleTable"
                            >
                                <>
                                    <thead>
                                        <tr className="">
                                            <th className="text-center">Date</th>
                                            <th className="text-center"> Pre  <br></br>Breakfast
                                            </th>
                                            <th className="text-center"> Post <br></br> Breakfast
                                            </th>
                                            <th className="text-center"> Pre <br></br>
                                                Lunch
                                            </th>

                                            <th className="text-center"> Post <br></br>
                                                Lunch
                                            </th>

                                            <th className="text-center"> Pre <br></br>
                                                Dinner
                                            </th>




                                        </tr>

                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className='text-center'>12/02/2024</td>
                                            <td className='text-center'>00</td>
                                            <td className='text-center'>00</td>
                                            <td className='text-center'>00</td>
                                            <td className='text-center'>00</td>
                                            <td className='text-center'>00</td>
                                        </tr>
                                    </tbody>
                                </>
                            </table>
                            <div className="posabs">
                                <button className="bontinue_btn" >
                                    CONTINUE
                                </button>
                            </div>
                        </div>
                    </div>
                </Col>
            </Row >
        </>
    )
}

export default DiabetesHis