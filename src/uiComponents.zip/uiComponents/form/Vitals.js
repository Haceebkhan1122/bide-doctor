import React, { useEffect, useMemo, useState, useRef } from "react";
import { Select, InputNumber, Form, Input, Button, Checkbox, Radio } from "antd";
import { Col, Row } from "react-bootstrap";
import arrowdropdown from "../../assets/images/svg/dropdown-icon.svg";
function Vitals() {
    return (
        <div className="p-40">
            <Form
                className="personalHistoryForm vitals"
            >
                <Row>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Weight</p>
                        <Form.Item
                            name="Weight"
                            rules={[{ required: false, }]}
                        >
                            <Select

                                dropdownAlign={{ offset: [0, 4] }}
                                style={{ cursor: "pointer" }}
                                className="form-control form001 newSelect"
                                placeholder="Select"
                                suffixIcon={<img src={arrowdropdown} alt />}
                                disabled
                            >

                                <option  >
                                    40kg
                                </option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Height</p>
                        <Form.Item
                            name="Height"
                            rules={[{ required: false, }]}
                        >
                            <Select

                                dropdownAlign={{ offset: [0, 4] }}
                                style={{ cursor: "pointer" }}
                                className="form-control form001 newSelect"
                                placeholder="Select"
                                suffixIcon={<img src={arrowdropdown} alt />}
                                disabled
                            >

                                <option  >
                                    5.5
                                </option>
                            </Select>
                        </Form.Item>


                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Heart Rate</p>
                        <Form.Item
                            name="Heart Rate"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Enter  "
                                readOnly />
                        </Form.Item>
                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Blood Pressure (Systolic)</p>
                        <Form.Item
                            name="Blood Pressure (Systolic)"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Enter  "
                                readOnly />
                        </Form.Item>
                    </Col>
                </Row>
                <Row className="mt-2">
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Blood Pressure (Diastolic)</p>
                        <Form.Item
                            name="Bloodpressure"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Select  "
                                readOnly />
                        </Form.Item>
                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">BMI</p>
                        <Form.Item
                            name="BMI"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Select  "
                                readOnly />
                        </Form.Item>


                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Temperaturet</p>
                        <Form.Item
                            name="temperaturet"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Enter  "
                                readOnly />
                        </Form.Item>
                    </Col>
                    <Col md={3} lg={3}>
                        <p className="labelText1 fs-14 ps-0">Glucometer Result</p>
                        <Form.Item
                            name="Glucometer"
                            rules={[{ required: false, }]}
                        >
                            <Input
                                className="form-control form002 newSelect"
                                placeholder="Enter  "
                                readOnly />
                        </Form.Item>
                    </Col>
                </Row>

            </Form>
        </div>
    )
}

export default Vitals