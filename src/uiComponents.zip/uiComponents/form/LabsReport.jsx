import React from 'react'
import "./medicalhistory.css";
function LabsReport() {
    return (
        <div className='medicleHistory labReport'>
            <table
                className="table medicleTable"
            >
                <>
                    <thead>
                        <tr className="">
                            <th className="text-center">Date</th>
                            <th className="text-center"> Lab <br></br>Name
                            </th>
                            <th className="text-center"> ECG
                            </th>
                            <th className="text-center"> RBS
                            </th>

                            <th className="text-center"> Hb1Ac
                            </th>

                            <th className="text-center"> S.Cr.
                            </th>

                            <th className="text-center"> Urine DR
                            </th>

                            <th className="text-center"> M.Alb
                            </th>

                            <th className="text-center"> 24h<br></br>
                                UP
                            </th>
                            <th className="text-center"> 24h <br></br>CCT
                            </th>

                            <th className="text-center"> Lipid
                            </th>


                        </tr>

                    </thead>
                    <tbody>
                        <tr>
                            <td className='text-center'>12/02/2024</td>
                            <td className='text-center'>Dow Hospital...</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                            <td className='text-center'>00</td>
                        </tr>
                    </tbody>
                </>
            </table>
        </div>
    )
}

export default LabsReport