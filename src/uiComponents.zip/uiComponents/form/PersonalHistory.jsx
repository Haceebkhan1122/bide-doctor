import React, { useEffect, useMemo, useState, useRef } from "react";
import { Select, InputNumber, Form, Input, Button, Checkbox, Radio } from "antd";
import { Col, Row } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import "./personalhistory.css";
import swal from "sweetalert";
import uniqBy from "lodash.uniqby";
import API from "../../utils/customAxios";
import arrowdropdown from "../../assets/images/svg/dropdown-icon.svg";
const PersonalHistory = () => {


    return (
        <div className="p-24 mainLabelClass">
            <Form
                className="personalHistoryForm"
            >
                <Row>
                    <Col lg={12}>
                        <Row className="spacing_grid">
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Marital Status</p>
                                <Form.Item
                                    name="status"
                                    rules={[{ required: true, message: "Required Medicine" }]}
                                >
                                    <Select

                                        dropdownAlign={{ offset: [0, 4] }}
                                        style={{ cursor: "pointer" }}
                                        className="form-control form001 newSelect"
                                        placeholder="Select status"
                                        suffixIcon={<img src={arrowdropdown} alt />}
                                        disabled
                                    >
                                        <option  >
                                            Single
                                        </option>
                                        <option  >
                                            married
                                        </option>
                                    </Select>
                                </Form.Item>
                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Occupation</p>
                                <Form.Item
                                    name="Occupation"
                                    rules={[{ required: false, }]}
                                >
                                    <Input
                                        className="form-control form002 newSelect"
                                        placeholder="Enter occupation"
                                        readOnly />
                                </Form.Item>

                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Lifestyle</p>
                                <div className="borderBox1 radioBox">

                                    <Radio.Group disabled>
                                        <Radio value="drinking">Drinking</Radio>
                                        <Radio value="smoking">Smoking</Radio>
                                    </Radio.Group>

                                </div>
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <Row>
                    <Col lg={12}>
                        <Row className="spacing_grid">
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Is patient’s father diabetic?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="fatherdiabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>

                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Is patient’s mother diabetic?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing" >

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="motherdiabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Is patient’s spouse diabetic?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="spousediabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>


                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Abortion</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled>
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="abortion"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <Row>
                    <Col lg={12}>
                        <Row className="spacing_grid">
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Is patient’s brother diabetic?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="brotherdiabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>

                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Is patient’s sister diabetic?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing" >

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="sisterdiabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Are patient’s children diabetic ?</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="childrendiabetic"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>


                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Neonatal Deaths</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled>
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="neonataldeaths"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <Row>
                    <Col lg={12}>
                        <Row className="spacing_grid">
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Live Birth</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing">

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="livebirth"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>

                            </Col>
                            <Col md={3} lg={3}>
                                <p className="labelText1 fs-14 ps-0">Still Birth</p>
                                <Row>
                                    <Col lg={6} className="pe-0">

                                        <div className="borderBox2 radioBox newSpacing" >

                                            <Radio.Group disabled defaultValue="yes">
                                                <Radio value="yes">Yes</Radio>
                                                <Radio value="no">No</Radio>
                                            </Radio.Group>

                                        </div>
                                    </Col>
                                    <Col lg={6}>
                                        <Form.Item
                                            name="stillbirth"
                                            rules={[{ required: false, }]}
                                        >
                                            <InputNumber placeholder="1234" className="form-control form002 newSelect" readOnly></InputNumber>

                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Col>

                        </Row>
                    </Col>
                </Row>
            </Form>
        </div>
    )
}

export default PersonalHistory