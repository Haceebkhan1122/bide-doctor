import React, { useEffect, useMemo, useState, useRef } from "react";
import { Select, InputNumber, Form, Input, Button, Checkbox } from "antd";
import { Col, Row } from "react-bootstrap";
import arrowdropdown from "../../assets/images/svg/dropdown-icon.svg";
import "./medform.css";
import swal from "sweetalert";
import arrowLeft from "../../assets/images/png/left-arrow.png";
import arrowRight from "../../assets/images/png/right-arrow.png";
export const InsulinForm = () => {
    const [showAddBtn, setShowAddBtn] = useState(false);
    const [typeName, setTypeName] = useState(null);
    const [medicineTypes, setMedicineTypes] = useState([]);
    const [med, setMed] = useState(null);
    const [medName, setMedName] = useState(null);
    const [morningDose, setMorningDose] = useState(null);
    const [afternoonDose, setAfternoonDose] = useState(null);
    const [eveningDose, setEveningDose] = useState(null);
    const [nightDose, setNightDose] = useState(null);
    const [durationNumber, setDurationNumber] = useState(null);
    const [mealStatus, setMealStatus] = useState(null);
    const [userForm] = Form.useForm();




    const medicineChange = (value) => {
        setMedName(value);
    };

    const typeChange = (value) => {
        setTypeName(value);
    };

    const changeMorning = (value) => {
        setMorningDose(value);
    };

    const changeAfternoon = (value) => {
        setAfternoonDose(value);
    };

    const changeEvening = (value) => {
        setEveningDose(value);
    };

    const changeNight = (value) => {
        setNightDose(value);
    };

    const durationChange = (value) => {
        setDurationNumber(value);
    };

    const mealChange = (value) => {
        setMealStatus(value);
    };
    function generateArrayWithoutNumber() {
        let res = [];
        for (let i = 0; i <= 255; i++) {
            if (i >= 48 && i <= 57) {
            } else {
                res.push(String.fromCharCode(i));
            }
        }
        return res;
    }

    const arrayWithoutNumber = useMemo(() => generateArrayWithoutNumber(), []);
    return (
        <>
            <Form
                name="basic"
                className="medicine_form01 insulineForm"

            >
                <Row className="spacing_grid1">
                   
                        <Col md={3} className="pe-3" >
                            <p className="labelText fs-14 ps-0">Choose Insulin*</p>
                            <Form.Item
                                name="medName"
                                rules={[{ required: true, message: "Required Medicine" }]}
                            >
                                <Select

                                    dropdownAlign={{ offset: [0, 4] }}
                                    style={{ cursor: "pointer" }}
                                    showSearch
                                    className="c_select"
                                    placeholder="Select insulin"
                                    suffixIcon={
                                        showAddBtn ? (
                                            <button className="add-custom-med">Add</button>
                                        ) : (
                                            <img src={arrowdropdown} alt />
                                        )
                                    }

                                    filterOption={(input, option) => {
                                        return option?.children
                                            ?.toLowerCase()
                                            ?.startsWith(input?.toLowerCase());
                                    }}
                                >
                                    <option>
                                        Option 1
                                    </option>
                                </Select>
                            </Form.Item>
                        </Col>
                        <Col md={3}>
                            <p className="labelText fs-14 ps-0">Units </p>
                            <Form.Item
                                name="Units"

                            >
                                <Select
                                    placeholder="Select unit"
                                    className="c_select"
                                    suffixIcon={<img src={arrowdropdown} alt />}>
                                    <Select.Option value="sample">Select 1</Select.Option>
                                    <Select.Option value="sample2">Select 2</Select.Option>
                                </Select>

                            </Form.Item>

                        </Col>
                    

                    <Col md={3}>
                        <p className="labelText fs-14 ps-0">Duration*</p>
                        <Form.Item
                            name="duration"
                            rules={[{ required: true, message: "Required duration" }]}
                        >
                            <Select
                                value={typeName}
                                dropdownAlign={{ offset: [0, 4] }}
                                placeholder="Select duration"
                                suffixIcon={<img src={arrowdropdown} alt />}
                                onChange={typeChange}
                                className="c_select"
                            >
                                <option>Option 1 </option>
                                <option>Option 2 </option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col md={3} className="row m-0  d-md-flex pt-0 newPrescriptionChecks ">
                        <Col md={3}>
                            {/* block for mobile  */}


                            <div className="mobile_design_field d-sm-block d-none">
                                <p className="labelText fs-14 ps-0">Morning</p>
                                <Form.Item name="morningDose">
                                    <InputNumber
                                        value={morningDose}
                                        min={1}
                                        max={99}
                                        maxLength={2}
                                        onKeyDown={(evt) =>
                                            arrayWithoutNumber.includes(evt.key) &&
                                            evt.preventDefault()
                                        }
                                    />
                                </Form.Item>
                            </div>
                        </Col>

                        <Col md={3} className=" d-sm-block d-none">
                            <p className="labelText fs-14 ps-0">Noon</p>
                            <Form.Item name="afternoonDose">
                                <InputNumber
                                    value={afternoonDose}
                                    min={1}
                                    max={99}
                                    maxLength={2}
                                    onChange={changeAfternoon}
                                    onKeyDown={(evt) =>
                                        arrayWithoutNumber.includes(evt.key) &&
                                        evt.preventDefault()
                                    }
                                />
                            </Form.Item>
                        </Col>

                        <Col md={3} className=" d-sm-block d-none">
                            <p className="labelText fs-14 ps-0">Evening</p>
                            <Form.Item name="eveningDose">
                                <InputNumber
                                    value={eveningDose}
                                    min={1}
                                    max={99}
                                    maxLength={2}
                                    onChange={changeEvening}
                                    onKeyDown={(evt) =>
                                        arrayWithoutNumber.includes(evt.key) &&
                                        evt.preventDefault()
                                    }
                                />
                            </Form.Item>
                        </Col>

                        <Col md={3} className=" d-sm-block d-none">
                            <p className="labelText fs-14 ps-0">Night</p>
                            <Form.Item name="nightDose">
                                <InputNumber
                                    max={99}
                                    maxLength={2}
                                    min={1}
                                    value={nightDose}
                                    onChange={changeNight}
                                    onKeyDown={(evt) =>
                                        arrayWithoutNumber.includes(evt.key) &&
                                        evt.preventDefault()
                                    } />

                            </Form.Item>
                        </Col>
                    </Col>
                </Row>
                <Row className=" ">
                    <Col
                        md={5} className="d-flex columspaacing">

                        <div className="hk_go_for_next">
                            <Checkbox className="ps-0">
                                Before Meal
                            </Checkbox>
                        </div>
                        <div className="hk_go_for_next">
                            <Checkbox >
                                After Meal
                            </Checkbox>
                        </div>
                    </Col>
                    </Row>
                    <Row className="mt-5">
                    <Col md={3} className="ms-auto">
                        <Button
                            type="primary"
                            htmlType="submit"
                            className="simple_btn_small"
                        >
                            ADD INSULIN
                        </Button>
                    </Col>
                </Row>
            </Form>
        </>
    )
}
