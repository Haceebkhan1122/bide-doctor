import React from 'react'
import "./medicalhistory.css";
function MedicalHistory() {
    return (
        <div className='medicleHistory'>
            <table
                className="table medicleTable"
            >
                <>
                    <thead>
                        <tr className="">
                            <th className="text-left">Date</th>
                            <th className=""> Question
                            </th>
                            <th className=""> Response
                            </th>
                            <th className=""> Remarks
                            </th>

                        </tr>

                    </thead>
                    <tbody>
                        <tr>
                            <td>12/02/2024</td>
                            <td>Previous Treatement</td>
                            <td>Yes</td>
                            <td>Had minor syrgery</td>
                        </tr>
                    </tbody>
                </>
            </table>
        </div>
    )
}

export default MedicalHistory